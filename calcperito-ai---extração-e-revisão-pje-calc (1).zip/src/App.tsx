import React, { useState } from 'react';
import { Header } from './components/Header';
import { UploadSection } from './components/UploadSection';
import { ReviewInterface } from './components/ReviewInterface';
import { PjeCalcExporter } from './components/PjeCalcExporter';
import { PjcConverterTool } from './components/PjcConverterTool';
import { LaudoGenerator } from './components/LaudoGenerator';
import { ExtracaoTrabalhista } from './types';
import { SampleCase } from './data/sampleCases';

export default function App() {
  const [activeTab, setActiveTab] = useState<'upload' | 'review' | 'export' | 'converter' | 'laudo' | 'samples'>('upload');
  const [extractedData, setExtractedData] = useState<ExtracaoTrabalhista | null>(null);

  // Manipulador quando um PDF ou texto é extraído via Gemini API
  const handleExtractionSuccess = (data: ExtracaoTrabalhista) => {
    setExtractedData(data);
    setActiveTab('review');
  };

  // Manipulador quando um caso de teste pré-carregado é escolhido
  const handleSelectSampleCase = (sample: SampleCase) => {
    setExtractedData(sample.extracaoEsperada);
    setActiveTab('review');
  };

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 flex flex-col font-sans selection:bg-emerald-500 selection:text-white">
      {/* Cabeçalho de Navegação */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        hasExtractedData={!!extractedData}
      />

      {/* Conteúdo Dinâmico Baseado na Aba Ativa */}
      <main className="flex-1 pb-16">
        {activeTab === 'upload' && (
          <UploadSection
            onExtractionSuccess={handleExtractionSuccess}
            onSelectSampleCase={handleSelectSampleCase}
          />
        )}

        {activeTab === 'review' && extractedData && (
          <ReviewInterface
            data={extractedData}
            onUpdateData={(updated) => setExtractedData(updated)}
            onProceedToExport={() => setActiveTab('export')}
          />
        )}

        {activeTab === 'export' && extractedData && (
          <PjeCalcExporter data={extractedData} />
        )}

        {activeTab === 'converter' && (
          <PjcConverterTool currentData={extractedData} />
        )}

        {activeTab === 'laudo' && extractedData && (
          <LaudoGenerator data={extractedData} />
        )}
      </main>

      {/* Rodapé Profissional */}
      <footer className="bg-slate-900 text-slate-400 py-6 text-xs border-t border-slate-800 mt-auto">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white">CalcPerito AI</span>
            <span>— Perícia Contábil & Automação PJe-Calc com Inteligência Artificial</span>
          </div>
          <p className="text-slate-500">
            Exportador Nativo .PJC • PJe-Calc Cidadão • OJ 394 SDI-1 TST • Gemini 3.6 Flash
          </p>
        </div>
      </footer>
    </div>
  );
}
