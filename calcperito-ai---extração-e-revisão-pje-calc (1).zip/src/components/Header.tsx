import React from 'react';
import { Calculator, FileText, CheckCircle2, Cpu, Download, Sparkles, BookOpen, FileCode } from 'lucide-react';

interface HeaderProps {
  activeTab: 'upload' | 'review' | 'export' | 'converter' | 'laudo' | 'samples';
  setActiveTab: (tab: 'upload' | 'review' | 'export' | 'converter' | 'laudo' | 'samples') => void;
  hasExtractedData: boolean;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, hasExtractedData }) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Identity */}
          <div className="flex items-center space-x-3">
            <div className="bg-emerald-500/20 text-emerald-400 p-2 rounded-xl border border-emerald-500/30">
              <Calculator className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white">CalcPerito <span className="text-emerald-400">AI</span></span>
                <span className="bg-emerald-500/10 text-emerald-400 text-xs px-2 py-0.5 rounded-full font-medium border border-emerald-500/20 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Automação PJe-Calc
                </span>
              </div>
              <p className="text-xs text-slate-400 hidden sm:block">Perícia Contábil & Extração Inteligente de Sentenças Trabalhistas</p>
            </div>
          </div>

          {/* Quick Engine Status */}
          <div className="hidden lg:flex items-center gap-3 text-xs bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/50 text-slate-300">
            <Cpu className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>Automação PJe-Calc Cidadão &amp; CalcMachine</span>
          </div>

          {/* Navigation Bar */}
          <nav className="flex items-center space-x-1 sm:space-x-2">
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
                activeTab === 'upload'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileText className="w-4 h-4" />
              <span className="hidden sm:inline">1. Extração PDF</span>
            </button>

            <button
              onClick={() => setActiveTab('review')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 relative ${
                activeTab === 'review'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span className="hidden sm:inline">2. Revisor IA</span>
              {hasExtractedData && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 absolute top-1 right-1 animate-ping" />
              )}
            </button>

            <button
              onClick={() => setActiveTab('export')}
              disabled={!hasExtractedData}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
                !hasExtractedData
                  ? 'opacity-50 cursor-not-allowed text-slate-500'
                  : activeTab === 'export'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">3. Automação PJe-Calc</span>
            </button>

            <button
              onClick={() => setActiveTab('converter')}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
                activeTab === 'converter'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <FileCode className="w-4 h-4" />
              <span className="hidden md:inline">Script &amp; JSON</span>
            </button>

            <button
              onClick={() => setActiveTab('laudo')}
              disabled={!hasExtractedData}
              className={`px-3 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all flex items-center gap-1.5 ${
                !hasExtractedData
                  ? 'opacity-50 cursor-not-allowed text-slate-500'
                  : activeTab === 'laudo'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span className="hidden md:inline">Laudo .DOCX</span>
            </button>
          </nav>
        </div>
      </div>
    </header>
  );
};
