import React, { useState } from 'react';
import { BookOpen, Download, FileText, CheckCircle2, ShieldCheck, Printer, Sparkles } from 'lucide-react';
import { ExtracaoTrabalhista } from '../types';

interface LaudoGeneratorProps {
  data: ExtracaoTrabalhista;
}

export const LaudoGenerator: React.FC<LaudoGeneratorProps> = ({ data }) => {
  const [isGeneratingDocx, setIsGeneratingDocx] = useState<boolean>(false);

  const handleDownloadDocx = async () => {
    try {
      setIsGeneratingDocx(true);
      const response = await fetch('/api/generate-docx-laudo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error('Erro ao gerar laudo em Word.');
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Laudo_Pericial_${data.processo.numero || 'Processo'}.docx`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Erro ao baixar Word:', err);
      alert('Falha ao gerar arquivo .docx do laudo pericial.');
    } finally {
      setIsGeneratingDocx(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">
      {/* Banner de Download do Laudo em Word */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-600 font-bold text-xs uppercase mb-1">
            <BookOpen className="w-4 h-4" />
            <span>Documento Técnico Judicial Próprio para Anexo</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900">
            Laudo Técnico Pericial (.DOCX)
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Gere e baixe o laudo em formato Microsoft Word pronto para anexar ao PJe ou entregar ao magistrado e partes.
          </p>
        </div>

        <button
          onClick={handleDownloadDocx}
          disabled={isGeneratingDocx}
          className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm px-6 py-3.5 rounded-xl transition-all shadow-md flex items-center justify-center gap-2 active:scale-95 whitespace-nowrap"
        >
          <Download className="w-4 h-4" />
          <span>{isGeneratingDocx ? 'Gerando Word...' : 'Baixar Laudo Técnico .DOCX'}</span>
        </button>
      </div>

      {/* Visualização de Prévia do Documento Judicial */}
      <div className="bg-white border border-slate-300 rounded-2xl p-8 sm:p-12 shadow-md space-y-8 text-slate-800 font-serif leading-relaxed max-w-4xl mx-auto">
        {/* Cabeçalho do Laudo */}
        <div className="text-center space-y-2 border-b-2 border-slate-900 pb-6">
          <h1 className="text-xl sm:text-2xl font-black tracking-tight text-slate-900 uppercase font-sans">
            LAUDO TÉCNICO PERICIAL DE CÁLCULOS TRABALHISTAS
          </h1>
          <p className="text-xs sm:text-sm font-sans font-semibold text-slate-600 uppercase tracking-wider">
            SISTEMA AUXILIAR DE LIQUIDAÇÃO DE SENTENÇA — PARÂMETROS INTEGRADOS AO PJE-CALC
          </p>
        </div>

        {/* 1. Dados do Processo */}
        <div className="space-y-3 font-sans">
          <h3 className="font-extrabold text-slate-900 text-base uppercase tracking-tight border-l-4 border-emerald-600 pl-3">
            1. DADOS IDENTIFICADORES DO PROCESSO
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 p-4 rounded-xl text-xs border border-slate-200">
            <div>
              <span className="font-bold text-slate-700">Processo Nº: </span>
              <span className="font-mono text-slate-900">{data.processo.numero || 'Não informado'}</span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Juízo: </span>
              <span>{data.processo.vara || ''} — {data.processo.tribunal || ''}</span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Reclamante (Autor): </span>
              <span className="font-semibold">{data.processo.reclamante}</span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Reclamado (Réu): </span>
              <span className="font-semibold">{data.processo.reclamado}</span>
            </div>
          </div>
        </div>

        {/* 2. Marcos Temporais */}
        <div className="space-y-3 font-sans">
          <h3 className="font-extrabold text-slate-900 text-base uppercase tracking-tight border-l-4 border-emerald-600 pl-3">
            2. MARCOS TEMPORAIS E PRESCRIÇÃO QUINQUENAL
          </h3>
          <div className="bg-slate-50 p-4 rounded-xl text-xs border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <span className="font-bold text-slate-700">Admissão: </span>
              <span className="font-mono">{data.datas.admissao}</span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Demissão: </span>
              <span className="font-mono">{data.datas.demissao}</span>
            </div>
            <div>
              <span className="font-bold text-slate-700">Ajuizamento: </span>
              <span className="font-mono">{data.datas.ajuizamento}</span>
            </div>
          </div>
        </div>

        {/* 3. Verbas Deferidas e Reflexos */}
        <div className="space-y-3 font-sans">
          <h3 className="font-extrabold text-slate-900 text-base uppercase tracking-tight border-l-4 border-emerald-600 pl-3">
            3. VERBAS TRABALHISTAS DEFERIDAS E REFLEXOS
          </h3>

          <div className="space-y-3">
            {data.verbas.map((v, index) => (
              <div key={v.id} className="p-4 rounded-xl border border-slate-200 bg-white text-xs space-y-1.5 shadow-2xs">
                <div className="flex items-center justify-between font-bold text-slate-900 text-sm">
                  <span>{index + 1}. {v.nome}</span>
                  <span className="bg-emerald-50 text-emerald-800 px-2 py-0.5 rounded border border-emerald-200 font-mono">
                    Adicional: {v.percentual ? `${v.percentual}%` : 'N/A'}
                  </span>
                </div>
                <p className="text-slate-600">
                  Divisor: <span className="font-mono font-semibold">{v.divisor || 220}</span> | Base de Cálculo: <span className="font-semibold">{v.baseCalculo || 'Salário Contratual'}</span>
                </p>
                <p className="text-slate-700 font-medium">
                  Reflexos Mapeados: <span className="text-emerald-700">{(v.reflexos || []).join(', ') || 'Sem reflexos'}</span>
                </p>
                {v.oj394 && (
                  <p className="text-emerald-800 font-semibold bg-emerald-50/80 p-1.5 rounded text-[11px] border border-emerald-200/60">
                    ✓ Respeitada a Tese Vinculante da OJ 394 da SDI-1 do TST (não repetição do DSR nas demais parcelas).
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* 4. Parecer Conclusivo */}
        <div className="space-y-3 font-sans">
          <h3 className="font-extrabold text-slate-900 text-base uppercase tracking-tight border-l-4 border-emerald-600 pl-3">
            4. PARECER CONCLUSIVO DO PERITO
          </h3>
          <p className="text-xs text-slate-700 bg-slate-50 p-4 rounded-xl border border-slate-200 leading-relaxed">
            {data.laudo?.conclusaoPericial || 'Os parâmetros acima foram extraídos e validados diretamente da decisão judicial com auxílio de Inteligência Artificial para parametrização do PJe-Calc Cidadão.'}
          </p>
        </div>

        {/* Assinatura Judicial */}
        <div className="pt-12 text-center font-sans space-y-1">
          <div className="w-64 border-t border-slate-800 mx-auto" />
          <p className="font-bold text-slate-900 text-sm">PERITO CONTÁBIL TRABALHISTA / CALCULISTA</p>
          <p className="text-xs text-slate-500">Inscrição CRC / AJPETRA • Sistema CalcPerito AI</p>
        </div>
      </div>
    </div>
  );
};
