import React, { useState } from 'react';
import { FileCode, Download, Upload, CheckCircle2, AlertCircle, Copy, Check, FileJson, ArrowRight, Sparkles, RefreshCw, Bot } from 'lucide-react';
import { convertJsonStringToPjc, downloadPjcFile, downloadCalcMachineJson, generateCalcMachineJson } from '../utils/pjcGenerator';
import { ExtracaoTrabalhista } from '../types';

interface PjcConverterToolProps {
  currentData?: ExtracaoTrabalhista | null;
}

export const PjcConverterTool: React.FC<PjcConverterToolProps> = ({ currentData }) => {
  const [jsonInput, setJsonInput] = useState<string>(
    currentData ? JSON.stringify(currentData, null, 2) : ''
  );
  const [convertedXml, setConvertedXml] = useState<string>(() => {
    if (currentData) {
      try {
        const result = convertJsonStringToPjc(JSON.stringify(currentData));
        return result.xml;
      } catch (e) {
        return '';
      }
    }
    return '';
  });
  const [convertedData, setConvertedData] = useState<ExtracaoTrabalhista | null>(
    currentData || null
  );
  const [fileName, setFileName] = useState<string>('Calculo_PJe.pjc');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedPjc, setCopiedPjc] = useState<boolean>(false);
  const [copiedCalcMachine, setCopiedCalcMachine] = useState<boolean>(false);
  const [activeViewTab, setActiveViewTab] = useState<'pjc' | 'calcmachine'>('calcmachine');

  const handleConvert = (rawJson: string) => {
    setErrorMsg(null);
    if (!rawJson.trim()) {
      setErrorMsg('Por favor, insira ou selecione um arquivo JSON de cálculo.');
      setConvertedXml('');
      setConvertedData(null);
      return;
    }

    try {
      const res = convertJsonStringToPjc(rawJson);
      setConvertedXml(res.xml);
      setConvertedData(res.data);
      setFileName(res.fileName);
    } catch (err: any) {
      setErrorMsg(err.message || 'Erro ao converter o arquivo JSON para o formato .PJC.');
      setConvertedXml('');
      setConvertedData(null);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      setJsonInput(content);
      handleConvert(content);
    };
    reader.readAsText(file);
  };

  const handleDownload = async () => {
    if (!convertedData) return;
    await downloadPjcFile(convertedData);
  };

  const handleDownloadCalcMachine = () => {
    if (!convertedData) return;
    downloadCalcMachineJson(convertedData);
  };

  const handleCopyXml = () => {
    if (!convertedXml) return;
    navigator.clipboard.writeText(convertedXml);
    setCopiedPjc(true);
    setTimeout(() => setCopiedPjc(false), 2500);
  };

  const handleCopyCalcMachine = () => {
    if (!convertedData) return;
    const calcMachineObj = generateCalcMachineJson(convertedData);
    navigator.clipboard.writeText(JSON.stringify(calcMachineObj, null, 2));
    setCopiedCalcMachine(true);
    setTimeout(() => setCopiedCalcMachine(false), 2500);
  };

  const calcMachineString = convertedData
    ? JSON.stringify(generateCalcMachineJson(convertedData), null, 2)
    : '';

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Banner Principal de Conversão .JSON -> .PJC / CalcMachine */}
      <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-slate-900 text-white p-6 sm:p-8 rounded-2xl border border-emerald-800 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Módulo de Conversão para PJe-Calc e CalcMachine</span>
          </div>
          <h2 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white">
            Gerador JSON CalcMachine &amp; Arquivo Native .PJC
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Converta seu JSON de dados no formato idêntico do <strong>CalcMachine</strong> (para extensões) ou gere o arquivo <strong>.PJC</strong> (para importação direta).
          </p>
        </div>

        {convertedData && (
          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleDownloadCalcMachine}
              className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs sm:text-sm px-5 py-3 rounded-xl transition-all shadow-lg flex items-center gap-2 active:scale-95 border border-emerald-400"
            >
              <Bot className="w-4 h-4 text-slate-950" />
              <span>Baixar CalcMachine JSON</span>
            </button>

            <button
              onClick={handleDownload}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 font-bold text-xs sm:text-sm px-4 py-3 rounded-xl transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-emerald-400" />
              <span>Baixar .PJC</span>
            </button>
          </div>
        )}
      </div>

      {/* Alerta de Compatibilidade PJe-Calc vs CalcMachine */}
      <div className="bg-amber-950/30 border border-amber-500/40 rounded-2xl p-6 text-slate-200 space-y-3">
        <div className="flex items-center gap-2.5 font-bold text-amber-300 text-sm sm:text-base">
          <AlertCircle className="w-5 h-5 shrink-0 text-amber-400" />
          <span>Informação Técnica Importante sobre a Importação de Arquivos no PJe-Calc:</span>
        </div>
        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
          O PJe-Calc Cidadão utiliza serialização de dados Java (XStream) ligada ao banco de dados interno de cada instalação local. Por isso, a importação nativa de arquivos <code className="bg-slate-900 text-amber-300 px-1.5 py-0.5 rounded font-mono text-xs">.PJC</code> no menu do sistema pode falhar com aviso de "arquivo inválido". Para contornar essa trava, utilize o formato <strong>CalcMachine JSON</strong> abaixo e injete os dados diretamente na tela do PJe-Calc através de extensões de navegador!
        </p>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Painel do JSON */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <FileJson className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-slate-900 text-base">Arquivo JSON de Origem</h3>
            </div>

            <label className="bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs px-3 py-2 rounded-xl cursor-pointer border border-slate-300 transition-all flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-emerald-600" />
              <span>Carregar arquivo .json</span>
              <input type="file" accept=".json" onChange={handleFileUpload} className="hidden" />
            </label>
          </div>

          <p className="text-xs text-slate-600">
            Cole ou carregue qualquer arquivo `.json` gerado pelo sistema para transformá-lo no formato do CalcMachine ou no arquivo nativo `.pjc`:
          </p>

          <textarea
            value={jsonInput}
            onChange={(e) => {
              setJsonInput(e.target.value);
              handleConvert(e.target.value);
            }}
            placeholder="Cole o JSON de extração trabalhista aqui..."
            className="w-full h-80 p-4 rounded-xl bg-slate-950 text-emerald-400 font-mono text-xs border border-slate-800 focus:ring-2 focus:ring-emerald-500 focus:outline-none resize-none leading-relaxed"
          />

          {errorMsg && (
            <div className="bg-red-50 text-red-700 p-3 rounded-xl text-xs border border-red-200 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-500 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => handleConvert(jsonInput)}
              className="bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all flex items-center gap-2"
            >
              <RefreshCw className="w-3.5 h-3.5 text-emerald-400" />
              <span>Processar Conversão</span>
            </button>

            <span className="text-[11px] text-slate-500 font-mono">
              Status: {convertedData ? '✅ Pronto' : 'Aguardando JSON'}
            </span>
          </div>
        </div>

        {/* Painel do JSON CalcMachine / .PJC XML Gerado */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col justify-between text-white">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveViewTab('calcmachine')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeViewTab === 'calcmachine'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>CalcMachine JSON</span>
                </button>

                <button
                  onClick={() => setActiveViewTab('pjc')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeViewTab === 'pjc'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>Estrutura .PJC</span>
                </button>
              </div>

              {activeViewTab === 'calcmachine' && convertedData && (
                <button
                  onClick={handleCopyCalcMachine}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1"
                >
                  {copiedCalcMachine ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCalcMachine ? 'Copiado!' : 'Copiar JSON'}</span>
                </button>
              )}

              {activeViewTab === 'pjc' && convertedXml && (
                <button
                  onClick={handleCopyXml}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1"
                >
                  {copiedPjc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPjc ? 'Copiado XML' : 'Copiar XML'}</span>
                </button>
              )}
            </div>

            {convertedData ? (
              <pre className="bg-slate-950 p-4 rounded-xl text-emerald-400 font-mono text-xs overflow-x-auto h-80 leading-relaxed border border-slate-800 selection:bg-emerald-600 selection:text-white">
                {activeViewTab === 'calcmachine' ? calcMachineString : convertedXml}
              </pre>
            ) : (
              <div className="h-80 bg-slate-950 rounded-xl border border-dashed border-slate-800 flex flex-col items-center justify-center text-slate-500 space-y-2 p-6 text-center">
                <FileCode className="w-10 h-10 text-slate-700" />
                <p className="text-xs font-semibold text-slate-400">Nenhum dado convertido ainda</p>
                <p className="text-[11px] text-slate-600 max-w-xs">
                  Forneça um JSON válido no painel à esquerda para gerar o formato CalcMachine e .PJC.
                </p>
              </div>
            )}
          </div>

          {/* Guia de Utilização */}
          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 text-slate-300 text-xs space-y-2">
            <p className="font-bold text-white flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>Como utilizar os dados no PJe-Calc:</span>
            </p>
            <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px] leading-relaxed">
              <li>
                <strong>Com Extensão (CalcMachine / Helper):</strong> Copie o <strong>CalcMachine JSON</strong> acima e cole no popup da extensão com a aba do PJe-Calc aberta.
              </li>
              <li>
                <strong>Importação Nativa (.PJC):</strong> Baixe o arquivo <strong>.PJC</strong> e acesse o menu <em>Cálculos &gt; Importar Cálculo...</em> dentro do PJe-Calc Cidadão.
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

