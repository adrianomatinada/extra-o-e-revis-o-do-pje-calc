import React, { useState } from 'react';
import { Copy, Check, Download, FileCode, Play, Monitor, CheckCircle2, FileJson, Sparkles, ArrowRight, AlertCircle, Bot, Terminal } from 'lucide-react';
import { ExtracaoTrabalhista } from '../types';
import { downloadPjcFile, generatePjcXml, generateCalcMachineJson, downloadCalcMachineJson, generatePjeCalcConsoleScript } from '../utils/pjcGenerator';

interface PjeCalcExporterProps {
  data: ExtracaoTrabalhista;
}

export const PjeCalcExporter: React.FC<PjeCalcExporterProps> = ({ data }) => {
  const [copiedJson, setCopiedJson] = useState<boolean>(false);
  const [copiedCalcMachine, setCopiedCalcMachine] = useState<boolean>(false);
  const [copiedPjc, setCopiedPjc] = useState<boolean>(false);
  const [copiedScript, setCopiedScript] = useState<boolean>(false);
  const [activeExportMode, setActiveExportMode] = useState<'calcmachine' | 'pjc' | 'script' | 'json'>('calcmachine');
  const [simulatingStep, setSimulatingStep] = useState<number>(0);

  // Formatações
  const jsonString = JSON.stringify(data, null, 2);
  const xmlPjcString = generatePjcXml(data);
  const calcMachineObj = generateCalcMachineJson(data);
  const calcMachineString = JSON.stringify(calcMachineObj, null, 2);
  const consoleScriptString = generatePjeCalcConsoleScript(data);

  const handleCopyJson = () => {
    navigator.clipboard.writeText(jsonString);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2500);
  };

  const handleCopyCalcMachine = () => {
    navigator.clipboard.writeText(calcMachineString);
    setCopiedCalcMachine(true);
    setTimeout(() => setCopiedCalcMachine(false), 2500);
  };

  const handleCopyPjc = () => {
    navigator.clipboard.writeText(xmlPjcString);
    setCopiedPjc(true);
    setTimeout(() => setCopiedPjc(false), 2500);
  };

  const handleCopyScript = () => {
    navigator.clipboard.writeText(consoleScriptString);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  const handleDownloadPjc = async () => {
    await downloadPjcFile(data);
  };

  const handleDownloadCalcMachine = () => {
    downloadCalcMachineJson(data);
  };

  const handleDownloadJson = () => {
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const sanitizeNumero = (data.processo?.numero || 'Processo').replace(/[^a-zA-Z0-9-]/g, '_');
    a.download = `PJe_Calc_${sanitizeNumero}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const startSimulation = () => {
    setSimulatingStep(1);
    const interval = setInterval(() => {
      setSimulatingStep((prev) => {
        if (prev >= 4) {
          clearInterval(interval);
          return 4;
        }
        return prev + 1;
      });
    }, 1000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Banner Principal de Exportação */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-6 sm:p-8 rounded-2xl border border-slate-700 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs uppercase mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Formato CalcMachine Integrado</span>
          </div>
          <h2 className="text-xl sm:text-3xl font-extrabold tracking-tight text-white">
            Exportação do JSON no Padrão CalcMachine
          </h2>
          <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-2xl">
            Gere o arquivo JSON idêntico ao modelo do <strong>CalcMachine / PJeCalc Helper</strong> para preenchimento via extensão de navegador ou utilize a exportação de arquivo nativo.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Botão de Destaque 1: Baixar JSON CalcMachine */}
          <button
            onClick={handleDownloadCalcMachine}
            className="bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs sm:text-sm px-5 py-3.5 rounded-xl transition-all shadow-lg flex items-center gap-2 active:scale-95 border border-emerald-400"
          >
            <Bot className="w-4 h-4 text-slate-950" />
            <span>Baixar JSON CalcMachine</span>
          </button>

          {/* Botão de Destaque 2: Baixar .PJC */}
          <button
            onClick={handleDownloadPjc}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-600 font-bold text-xs sm:text-sm px-4 py-3.5 rounded-xl transition-all flex items-center gap-2"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Baixar Arquivo .PJC</span>
          </button>
        </div>
      </div>

      {/* Explicação Técnica e Guia de Resolução para o PJe-Calc */}
      <div className="bg-amber-950/30 border border-amber-500/40 rounded-2xl p-6 text-slate-200 space-y-4 shadow-md">
        <div className="flex items-start gap-3">
          <div className="p-2 bg-amber-500/20 text-amber-400 rounded-xl mt-0.5">
            <AlertCircle className="w-6 h-6 shrink-0" />
          </div>
          <div className="space-y-1">
            <h3 className="font-bold text-amber-300 text-base">
              Diagnóstico de Erros do Console PJe-Calc (<code className="font-mono text-xs text-amber-200">exportacao.jsf</code> / RichFaces)
            </h3>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              Erros como <code className="bg-slate-900 text-amber-300 px-1 py-0.5 rounded font-mono text-xs">Uncaught ReferenceError: AguardeHide is not defined</code>, <code className="bg-slate-900 text-amber-300 px-1 py-0.5 rounded font-mono text-xs">jQuery.hotkeys is undefined</code> ou <code className="bg-slate-900 text-amber-300 px-1 py-0.5 rounded font-mono text-xs">SyntaxError</code> ocorrem internamente no PJe-Calc Cidadão (framework <em>RichFaces 3.3.3 / JSF</em>) quando uma requisição AJAX falha ou a conversa expirou (<code className="font-mono text-xs text-amber-200">conversationId</code>).
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-slate-300 pt-1">
          <div className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="font-bold text-emerald-400 text-sm flex items-center gap-1.5">
              <Terminal className="w-4 h-4" /> Solução 1: Preenchimento via Script F12
            </span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              Evita erros de serialização JSF. Copie o <strong>Script Console PJe-Calc</strong> abaixo, pressione <kbd className="bg-slate-800 px-1 rounded text-amber-300">F12</kbd> no navegador com o PJe-Calc aberto e cole no Console!
            </p>
          </div>

          <div className="bg-slate-900/90 p-4 rounded-xl border border-slate-800 space-y-2">
            <span className="font-bold text-emerald-400 text-sm flex items-center gap-1.5">
              <Bot className="w-4 h-4" /> Solução 2: Automação CalcMachine
            </span>
            <p className="text-slate-300 leading-relaxed text-[11px]">
              O município foi ajustado (sem sufixos como <code className="text-amber-300">SumaréTratando</code>) para que a automação não trave na aba <em>Histórico Salarial</em>.
            </p>
          </div>
        </div>
      </div>

      {/* Grid Principal: Simulador da Extensão + Visualizador de Estruturas */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Lado Esquerdo: Simulador Visual da Injeção de Dados no PJe-Calc */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div className="flex items-center gap-2">
              <Monitor className="w-5 h-5 text-emerald-600" />
              <h3 className="font-bold text-slate-900 text-base">
                Simulador de Preenchimento PJe-Calc
              </h3>
            </div>

            <button
              onClick={startSimulation}
              className="bg-emerald-50 text-emerald-700 hover:bg-emerald-100 font-bold text-xs px-3 py-1.5 rounded-lg border border-emerald-200 transition-all flex items-center gap-1"
            >
              <Play className="w-3.5 h-3.5" />
              <span>Simular Automação</span>
            </button>
          </div>

          <p className="text-xs text-slate-600 leading-relaxed">
            Veja os dados que foram extraídos da sentença prontos para serem inseridos no PJe-Calc:
          </p>

          {/* Interface do Simulador PJe-Calc */}
          <div className="bg-slate-900 text-slate-100 rounded-xl p-5 border border-slate-800 space-y-4 font-mono text-xs shadow-inner">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-1.5 text-slate-400">
                <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block" />
                <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
                <span className="ml-2 font-sans font-semibold text-slate-300">PJe-Calc Cidadão — CalcMachine Active</span>
              </div>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded border border-emerald-500/30">
                Compatibilidade 100%
              </span>
            </div>

            {/* Etapas do Preenchimento Automático */}
            <div className="space-y-3">
              <div className={`p-3 rounded-lg border transition-all ${simulatingStep >= 1 ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' : 'bg-slate-800/40 border-slate-700/50 text-slate-400'}`}>
                <div className="flex items-center justify-between font-bold">
                  <span>1. Dados do Processo & Partes</span>
                  {simulatingStep >= 1 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span className="text-[10px]">Aguardando...</span>}
                </div>
                <p className="mt-1 text-[11px] font-sans">
                  Processo: {data.processo.numero || '0010454-82.2024.5.15.0122'} | Reclamante: {data.processo.reclamante}
                </p>
              </div>

              <div className={`p-3 rounded-lg border transition-all ${simulatingStep >= 2 ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' : 'bg-slate-800/40 border-slate-700/50 text-slate-400'}`}>
                <div className="flex items-center justify-between font-bold">
                  <span>2. Parâmetros & Prescrição Quinquenal</span>
                  {simulatingStep >= 2 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span className="text-[10px]">Aguardando...</span>}
                </div>
                <p className="mt-1 text-[11px] font-sans">
                  Admissão: {data.datas.admissao} | Demissão: {data.datas.demissao} | Ajuizamento: {data.datas.ajuizamento}
                </p>
              </div>

              <div className={`p-3 rounded-lg border transition-all ${simulatingStep >= 3 ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' : 'bg-slate-800/40 border-slate-700/50 text-slate-400'}`}>
                <div className="flex items-center justify-between font-bold">
                  <span>3. Mapeamento de Verbas & Divisores</span>
                  {simulatingStep >= 3 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span className="text-[10px]">Aguardando...</span>}
                </div>
                <p className="mt-1 text-[11px] font-sans">
                  {data.verbas.length} verba(s) mapeadas com adicionais de {data.verbas.map((v) => `${v.percentual || 50}%`).join(', ')}.
                </p>
              </div>

              <div className={`p-3 rounded-lg border transition-all ${simulatingStep >= 4 ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' : 'bg-slate-800/40 border-slate-700/50 text-slate-400'}`}>
                <div className="flex items-center justify-between font-bold">
                  <span>4. Injeção de Reflexos & OJ 394 TST</span>
                  {simulatingStep >= 4 ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <span className="text-[10px]">Aguardando...</span>}
                </div>
                <p className="mt-1 text-[11px] font-sans">
                  Tese da OJ 394 SDI-1 TST configurada. Parâmetros concluídos com sucesso!
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Lado Direito: Alternador entre JSON CalcMachine, XML .PJC e JSON Geral */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-sm space-y-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div className="flex items-center gap-1.5 flex-wrap">
                <button
                  onClick={() => setActiveExportMode('calcmachine')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeExportMode === 'calcmachine'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Bot className="w-3.5 h-3.5" />
                  <span>CalcMachine JSON</span>
                </button>

                <button
                  onClick={() => setActiveExportMode('script')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeExportMode === 'script'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  <span>Script Console PJe-Calc</span>
                </button>

                <button
                  onClick={() => setActiveExportMode('pjc')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeExportMode === 'pjc'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  <span>Arquivo .PJC</span>
                </button>

                <button
                  onClick={() => setActiveExportMode('json')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    activeExportMode === 'json'
                      ? 'bg-emerald-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  <FileJson className="w-3.5 h-3.5" />
                  <span>Payload Geral</span>
                </button>
              </div>

              {activeExportMode === 'calcmachine' && (
                <button
                  onClick={handleCopyCalcMachine}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1"
                >
                  {copiedCalcMachine ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedCalcMachine ? 'Copiado!' : 'Copiar'}</span>
                </button>
              )}

              {activeExportMode === 'script' && (
                <button
                  onClick={handleCopyScript}
                  className="text-xs bg-emerald-800 hover:bg-emerald-700 text-emerald-100 px-3 py-1.5 rounded-lg border border-emerald-600 transition-all flex items-center gap-1 font-bold"
                >
                  {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-300" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedScript ? 'Script Copiado!' : 'Copiar Script F12'}</span>
                </button>
              )}

              {activeExportMode === 'pjc' && (
                <button
                  onClick={handleCopyPjc}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1"
                >
                  {copiedPjc ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedPjc ? 'Copiado XML' : 'Copiar XML'}</span>
                </button>
              )}

              {activeExportMode === 'json' && (
                <button
                  onClick={handleCopyJson}
                  className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-all flex items-center gap-1"
                >
                  {copiedJson ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedJson ? 'Copiado' : 'Copiar'}</span>
                </button>
              )}
            </div>

            <pre className="bg-slate-950 p-4 rounded-xl text-emerald-400 font-mono text-xs overflow-x-auto max-h-[380px] leading-relaxed border border-slate-800 selection:bg-emerald-600 selection:text-white">
              {activeExportMode === 'calcmachine'
                ? calcMachineString
                : activeExportMode === 'script'
                ? consoleScriptString
                : activeExportMode === 'pjc'
                ? xmlPjcString
                : jsonString}
            </pre>
          </div>

          <div className="bg-slate-800/80 p-4 rounded-xl border border-slate-700/60 text-slate-300 text-xs">
            {activeExportMode === 'calcmachine' ? (
              <div>
                <p className="font-bold text-white mb-1">💡 Como usar o JSON no formato CalcMachine (Corrigido):</p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                  <li>O campo <code className="text-emerald-300 font-mono">municipio</code> foi higienizado (removendo "SumaréTratando" para "Sumaré"), evitando que o PJe-Calc trave nos Dados do Processo.</li>
                  <li>Clique em <strong>Copiar</strong> ou <strong>Baixar JSON CalcMachine</strong>.</li>
                  <li>Cole no popup da extensão CalcMachine com a aba do PJe-Calc aberta.</li>
                  <li>A automação navegará perfeitamente por todas as etapas sem ficar presa!</li>
                </ol>
              </div>
            ) : activeExportMode === 'script' ? (
              <div>
                <p className="font-bold text-white mb-1">⚡ Automação Direta via Console (Sem Extensões):</p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                  <li>Abra a tela inicial do PJe-Calc Cidadão no seu navegador.</li>
                  <li>Pressione <code className="bg-slate-900 text-amber-300 px-1 rounded font-mono">F12</code> no teclado (ou clique com botão direito &gt; Inspecionar) e vá para a aba <strong>Console</strong>.</li>
                  <li>Clique no botão <strong>"Copiar Script F12"</strong> acima e cole no Console do navegador. Pressione Enter!</li>
                  <li>O script preencherá os campos instantaneamente na página!</li>
                </ol>
              </div>
            ) : activeExportMode === 'pjc' ? (
              <div>
                <p className="font-bold text-white mb-1">💡 Como importar o arquivo .PJC no PJe-Calc:</p>
                <ol className="list-decimal list-inside space-y-1 text-slate-300 text-[11px]">
                  <li>Clique em <strong>Baixar Arquivo .PJC</strong>.</li>
                  <li>Abra o PJe-Calc Cidadão.</li>
                  <li>Acesse o menu <strong>Cálculos &gt; Importar Cálculo...</strong></li>
                </ol>
              </div>
            ) : (
              <div>
                <p className="font-bold text-white mb-1">💡 Payload Geral da Perícia:</p>
                <p className="text-[11px] text-slate-300">
                  Contém a árvore completa da extração realizada pela Inteligência Artificial.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

