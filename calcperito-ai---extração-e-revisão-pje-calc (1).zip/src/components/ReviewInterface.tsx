import React, { useState } from 'react';
import { CheckCircle2, AlertTriangle, Plus, Trash2, Edit3, Save, ShieldCheck, DollarSign, Calendar, FileCheck, Layers, ChevronDown, ChevronUp, RefreshCw, ArrowRight } from 'lucide-react';
import { ExtracaoTrabalhista, VerbaDeferida, TipoVerba } from '../types';

interface ReviewInterfaceProps {
  data: ExtracaoTrabalhista;
  onUpdateData: (newData: ExtracaoTrabalhista) => void;
  onProceedToExport: () => void;
}

const ALL_REFLEXOS_OPTIONS = [
  'Férias + 1/3',
  '13º Salário',
  'Aviso Prévio',
  'FGTS + 40%',
  'DSR',
  'Multa Art. 477 CLT',
  'Multa Art. 467 CLT',
  'Gratificação Natalina',
];

export const ReviewInterface: React.FC<ReviewInterfaceProps> = ({
  data,
  onUpdateData,
  onProceedToExport,
}) => {
  const [activeSection, setActiveSection] = useState<'verbas' | 'processo' | 'datas' | 'historico' | 'honorarios'>('verbas');
  const [showAddVerbaModal, setShowAddVerbaModal] = useState<boolean>(false);
  const [newVerba, setNewVerba] = useState<Partial<VerbaDeferida>>({
    nome: '',
    tipo: 'horas_extras',
    percentual: 50,
    divisor: 220,
    baseCalculo: 'Salário Base',
    oj394: true,
    reflexos: ['Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
  });

  // Validação de Progresso
  const totalVerbas = data.verbas.length;
  const verbasAprovadasCount = data.verbas.filter((v) => v.statusRevisao === 'aprovado' || v.statusRevisao === 'editado').length;
  const progressPercentage = totalVerbas > 0 ? Math.round((verbasAprovadasCount / totalVerbas) * 100) : 100;

  // Handlers de alteração de campos do processo
  const handleProcessoChange = (field: string, value: string) => {
    onUpdateData({
      ...data,
      processo: {
        ...data.processo,
        [field]: value,
      },
    });
  };

  // Handlers de alteração de datas
  const handleDatasChange = (field: string, value: string) => {
    onUpdateData({
      ...data,
      datas: {
        ...data.datas,
        [field]: value,
      },
    });
  };

  // Alterar status da verba (Aprovar/Editar)
  const toggleVerbaStatus = (id: string) => {
    const updatedVerbas = data.verbas.map((v) => {
      if (v.id === id) {
        const nextStatus: VerbaDeferida['statusRevisao'] = v.statusRevisao === 'aprovado' ? 'pendente' : 'aprovado';
        return { ...v, statusRevisao: nextStatus };
      }
      return v;
    });
    onUpdateData({ ...data, verbas: updatedVerbas });
  };

  // Aprovar todas as verbas
  const handleApproveAllVerbas = () => {
    const updatedVerbas = data.verbas.map((v) => ({ ...v, statusRevisao: 'aprovado' as const }));
    onUpdateData({ ...data, verbas: updatedVerbas });
  };

  // Atualizar campo de verba
  const handleVerbaUpdate = (id: string, field: keyof VerbaDeferida, value: any) => {
    const updatedVerbas = data.verbas.map((v) => {
      if (v.id === id) {
        return {
          ...v,
          [field]: value,
          statusRevisao: 'editado' as const,
        };
      }
      return v;
    });
    onUpdateData({ ...data, verbas: updatedVerbas });
  };

  // Toggle de reflexo em uma verba
  const toggleReflexoInVerba = (id: string, reflexoName: string) => {
    const updatedVerbas = data.verbas.map((v) => {
      if (v.id === id) {
        const currentReflexos = v.reflexos || [];
        const hasReflexo = currentReflexos.includes(reflexoName);
        const newReflexos = hasReflexo
          ? currentReflexos.filter((r) => r !== reflexoName)
          : [...currentReflexos, reflexoName];
        return {
          ...v,
          reflexos: newReflexos,
          statusRevisao: 'editado' as const,
        };
      }
      return v;
    });
    onUpdateData({ ...data, verbas: updatedVerbas });
  };

  // Remover verba
  const handleRemoveVerba = (id: string) => {
    const updatedVerbas = data.verbas.filter((v) => v.id !== id);
    onUpdateData({ ...data, verbas: updatedVerbas });
  };

  // Adicionar nova verba
  const handleAddVerbaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVerba.nome) return;

    const vCreated: VerbaDeferida = {
      id: `v-custom-${Date.now()}`,
      nome: newVerba.nome || 'Nova Verba',
      tipo: newVerba.tipo || 'outro',
      percentual: newVerba.percentual || null,
      valorEstimado: newVerba.valorEstimado || null,
      quantidadeMensal: newVerba.quantidadeMensal || null,
      divisor: newVerba.divisor || 220,
      baseCalculo: newVerba.baseCalculo || 'Salário Base',
      oj394: !!newVerba.oj394,
      reflexos: newVerba.reflexos || [],
      observacoes: newVerba.observacoes || '',
      statusRevisao: 'aprovado',
    };

    onUpdateData({
      ...data,
      verbas: [...data.verbas, vCreated],
    });

    setShowAddVerbaModal(false);
    setNewVerba({
      nome: '',
      tipo: 'horas_extras',
      percentual: 50,
      divisor: 220,
      baseCalculo: 'Salário Base',
      oj394: true,
      reflexos: ['Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 space-y-8">
      {/* Barra Superior de Status e Resumo do Processo */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-1 rounded-full border border-emerald-200">
                PROCESSO N.º {data.processo.numero || 'Não informado'}
              </span>
              <span className="text-xs text-slate-500 font-medium">
                {data.processo.vara} • {data.processo.tribunal}
              </span>
            </div>

            <h2 className="text-xl font-extrabold text-slate-900 tracking-tight">
              {data.processo.reclamante} <span className="text-slate-400 font-normal">VS</span> {data.processo.reclamado}
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Documento: <span className="font-medium text-slate-700">{data.nomeArquivo || 'Petição / Sentença'}</span> • Extraído em {new Date(data.dataExtracao).toLocaleDateString('pt-BR')}
            </p>
          </div>

          {/* Validador de Progresso */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 min-w-[280px]">
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1.5">
              <span>Validação das Verbas</span>
              <span className="text-emerald-600 font-mono">{verbasAprovadasCount} de {totalVerbas} aprovadas ({progressPercentage}%)</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
              <div
                className="bg-emerald-500 h-2.5 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
            <div className="flex items-center justify-between mt-3">
              <button
                onClick={handleApproveAllVerbas}
                className="text-xs font-semibold text-emerald-700 hover:text-emerald-800 underline flex items-center gap-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Aprovar Todas as Verbas</span>
              </button>

              <button
                onClick={onProceedToExport}
                className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded-lg transition-all shadow-sm flex items-center gap-1"
              >
                <span>Avançar para PJe-Calc</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Navegação por Blocos de Dados */}
      <div className="flex items-center gap-2 border-b border-slate-200 overflow-x-auto pb-2">
        <button
          onClick={() => setActiveSection('verbas')}
          className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSection === 'verbas'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Layers className="w-4 h-4" />
          <span>Verbas Deferidas ({data.verbas.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('processo')}
          className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSection === 'processo'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <FileCheck className="w-4 h-4" />
          <span>Dados do Processo</span>
        </button>

        <button
          onClick={() => setActiveSection('datas')}
          className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSection === 'datas'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>Marcos & Prescrição</span>
        </button>

        <button
          onClick={() => setActiveSection('historico')}
          className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSection === 'historico'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <DollarSign className="w-4 h-4" />
          <span>Evolução Salarial</span>
        </button>

        <button
          onClick={() => setActiveSection('honorarios')}
          className={`px-4 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeSection === 'honorarios'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <ShieldCheck className="w-4 h-4" />
          <span>Honorários & Perícia</span>
        </button>
      </div>

      {/* CONTEÚDO DA SEÇÃO 1: VERBAS DEFERIDAS (CORE) */}
      {activeSection === 'verbas' && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Bloco de Verbas Deferidas e Mapeamento de Reflexos</h3>
              <p className="text-xs text-slate-500">
                Revise os adicionais, percentuais, quantidade mensal, OJ 394 TST e clique nas tags de reflexos para ativar/desativar a apuração.
              </p>
            </div>

            <button
              onClick={() => setShowAddVerbaModal(true)}
              className="bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold px-4 py-2.5 rounded-xl transition-all shadow-sm flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>Adicionar Nova Verba</span>
            </button>
          </div>

          {/* Cards de Verbas */}
          <div className="grid grid-cols-1 gap-6">
            {data.verbas.map((v, index) => {
              const isApproved = v.statusRevisao === 'aprovado';
              const isEdited = v.statusRevisao === 'editado';

              return (
                <div
                  key={v.id}
                  className={`bg-white border rounded-2xl p-6 shadow-sm transition-all relative ${
                    isApproved
                      ? 'border-emerald-300 ring-1 ring-emerald-300/50 bg-emerald-50/20'
                      : isEdited
                      ? 'border-amber-300 ring-1 ring-amber-300/50 bg-amber-50/20'
                      : 'border-slate-300 hover:border-slate-400'
                  }`}
                >
                  <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4 border-b border-slate-100 pb-4 mb-4">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-400 font-mono">#{index + 1}</span>
                        <input
                          type="text"
                          value={v.nome}
                          onChange={(e) => handleVerbaUpdate(v.id, 'nome', e.target.value)}
                          className="font-extrabold text-slate-900 text-base sm:text-lg border-b border-dashed border-slate-300 focus:border-emerald-500 outline-none bg-transparent"
                        />
                        {isApproved && (
                          <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Validada
                          </span>
                        )}
                        {isEdited && (
                          <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded-full">
                            Editada
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500">{v.observacoes || 'Sem observações adicionais.'}</p>
                    </div>

                    {/* Botões de Ação na Verba */}
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleVerbaStatus(v.id)}
                        className={`text-xs font-bold px-3 py-1.5 rounded-lg border transition-all flex items-center gap-1 ${
                          isApproved
                            ? 'bg-slate-100 text-slate-700 border-slate-300 hover:bg-slate-200'
                            : 'bg-emerald-600 text-white border-emerald-600 hover:bg-emerald-700 shadow-sm'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>{isApproved ? 'Marcar Pendente' : 'Aprovar Verba'}</span>
                      </button>

                      <button
                        onClick={() => handleRemoveVerba(v.id)}
                        className="text-red-600 hover:text-red-700 p-1.5 rounded-lg hover:bg-red-50 border border-transparent hover:border-red-200 transition-all"
                        title="Remover Verba"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Formulário de Parâmetros da Verba */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs mb-5">
                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">Tipo da Verba</label>
                      <select
                        value={v.tipo}
                        onChange={(e) => handleVerbaUpdate(v.id, 'tipo', e.target.value as TipoVerba)}
                        className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500 bg-white"
                      >
                        <option value="horas_extras">Horas Extras</option>
                        <option value="acumulo_funcao">Acúmulo de Função</option>
                        <option value="insalubridade">Adicional de Insalubridade</option>
                        <option value="periculosidade">Adicional de Periculosidade</option>
                        <option value="adicional_noturno">Adicional Noturno</option>
                        <option value="diferenca_salarial">Diferença Salarial / Equiparação</option>
                        <option value="intervalo_intrajornada">Intervalo Intrajornada</option>
                        <option value="danos_morais">Danos Morais</option>
                        <option value="multa_art_477">Multa Art. 477 CLT</option>
                        <option value="multa_art_467">Multa Art. 467 CLT</option>
                        <option value="outro">Outro Título</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">Adicional / Percentual (%)</label>
                      <input
                        type="number"
                        value={v.percentual ?? ''}
                        onChange={(e) => handleVerbaUpdate(v.id, 'percentual', e.target.value ? Number(e.target.value) : null)}
                        placeholder="Ex: 50, 20, 40"
                        className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500 bg-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">Quantidade Mensal / Horas</label>
                      <input
                        type="number"
                        step="0.01"
                        value={v.quantidadeMensal ?? ''}
                        onChange={(e) => handleVerbaUpdate(v.id, 'quantidadeMensal', e.target.value ? Number(e.target.value) : null)}
                        placeholder="Ex: 42.86"
                        className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500 bg-white font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-slate-500 font-semibold mb-1">Divisor da Jornada</label>
                      <select
                        value={v.divisor ?? 220}
                        onChange={(e) => handleVerbaUpdate(v.id, 'divisor', Number(e.target.value))}
                        className="w-full p-2 border border-slate-300 rounded-lg outline-none focus:ring-1 focus:ring-emerald-500 bg-white font-mono"
                      >
                        <option value={220}>220 (44h semanais)</option>
                        <option value={200}>200 (40h semanais)</option>
                        <option value={180}>180 (36h semanais)</option>
                        <option value={150}>150 (30h semanais)</option>
                      </select>
                    </div>
                  </div>

                  {/* Mapeamento de Reflexos (Interactive Chips) */}
                  <div className="space-y-2 bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-slate-800 uppercase tracking-wider">Reflexos Deferidos em Outras Verbas:</span>
                      <span className="text-[11px] text-slate-500">Clique na tag para ativar ou desativar</span>
                    </div>

                    <div className="flex flex-wrap gap-2 pt-1">
                      {ALL_REFLEXOS_OPTIONS.map((reflexo) => {
                        const isSelected = (v.reflexos || []).includes(reflexo);
                        return (
                          <button
                            key={reflexo}
                            type="button"
                            onClick={() => toggleReflexoInVerba(v.id, reflexo)}
                            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all border ${
                              isSelected
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                : 'bg-white text-slate-600 border-slate-300 hover:border-slate-400'
                            }`}
                          >
                            {isSelected ? '✓ ' : '+ '}
                            {reflexo}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* Toggle para OJ 394 TST */}
                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={v.oj394}
                        onChange={(e) => handleVerbaUpdate(v.id, 'oj394', e.target.checked)}
                        className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
                      />
                      <span className="font-bold text-slate-800">
                        Observar tese vinculante da OJ 394 da SDI-1 do TST (Sem repetição de DSR nas demais parcelas)
                      </span>
                    </label>

                    <span className="text-[11px] text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded border border-emerald-200 hidden sm:inline-block font-mono">
                      PJe-Calc Option: oj394={v.oj394 ? 'true' : 'false'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* CONTEÚDO DA SEÇÃO 2: DADOS DO PROCESSO */}
      {activeSection === 'processo' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
            Dados Identificadores do Processo Judicial
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Número do Processo (CNJ)</label>
              <input
                type="text"
                value={data.processo.numero || ''}
                onChange={(e) => handleProcessoChange('numero', e.target.value)}
                placeholder="0000000-00.0000.5.00.0000"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-semibold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Reclamante (Autor/Trabalhador)</label>
              <input
                type="text"
                value={data.processo.reclamante || ''}
                onChange={(e) => handleProcessoChange('reclamante', e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Reclamado (Empresa/Réu)</label>
              <input
                type="text"
                value={data.processo.reclamado || ''}
                onChange={(e) => handleProcessoChange('reclamado', e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-semibold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Tribunal Regional do Trabalho</label>
              <input
                type="text"
                value={data.processo.tribunal || ''}
                onChange={(e) => handleProcessoChange('tribunal', e.target.value)}
                placeholder="TRT 15ª Região"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Vara do Trabalho de Origem</label>
              <input
                type="text"
                value={data.processo.vara || ''}
                onChange={(e) => handleProcessoChange('vara', e.target.value)}
                placeholder="2ª Vara do Trabalho de Paulínia"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">UF</label>
              <input
                type="text"
                value={data.processo.uf || ''}
                onChange={(e) => handleProcessoChange('uf', e.target.value)}
                placeholder="SP"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 text-slate-900 uppercase font-mono"
              />
            </div>
          </div>
        </div>
      )}

      {/* CONTEÚDO DA SEÇÃO 3: MARCOS TEMPORAIS E PRESCRIÇÃO */}
      {activeSection === 'datas' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
            Marcos Temporais e Cálculo da Prescrição Quinquenal (Art. 7º, XXIX CF)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data de Admissão</label>
              <input
                type="text"
                value={data.datas.admissao || ''}
                onChange={(e) => handleDatasChange('admissao', e.target.value)}
                placeholder="DD/MM/AAAA"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data de Demissão / Rescisão</label>
              <input
                type="text"
                value={data.datas.demissao || ''}
                onChange={(e) => handleDatasChange('demissao', e.target.value)}
                placeholder="DD/MM/AAAA"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Data de Ajuizamento da Ação</label>
              <input
                type="text"
                value={data.datas.ajuizamento || ''}
                onChange={(e) => handleDatasChange('ajuizamento', e.target.value)}
                placeholder="DD/MM/AAAA"
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono text-slate-900"
              />
            </div>
          </div>

          {/* Banner de Prescrição Quinquenal */}
          <div className="bg-amber-50 border border-amber-200 p-5 rounded-xl flex items-start gap-3 text-xs sm:text-sm text-amber-900">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="space-y-1">
              <span className="font-bold text-amber-950 block">Marco de Prescrição Quinquenal Apurado:</span>
              <p>
                {data.datas.prescricaoQuinquenal
                  ? `Parcelas anteriores a ${data.datas.prescricaoQuinquenal} estão declaradas prescritas para fins de apuração de liquidação no PJe-Calc.`
                  : 'Nenhuma prescrição quinquenal declarada pelo magistrado.'}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CONTEÚDO DA SEÇÃO 4: HISTÓRICO SALARIAL */}
      {activeSection === 'historico' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-slate-900">Evolução Salarial Contratual</h3>
              <p className="text-xs text-slate-500">
                Ajuste os valores base utilizados para os divisores e reflexos das horas extras e adicionais.
              </p>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-xl">
            <table className="w-full text-left text-xs sm:text-sm text-slate-800">
              <thead className="bg-slate-100 uppercase text-[11px] font-bold text-slate-600 border-b border-slate-200">
                <tr>
                  <th className="p-3">Competência</th>
                  <th className="p-3">Salário Base (R$)</th>
                  <th className="p-3">Gratificações (R$)</th>
                  <th className="p-3">Total Remuneração (R$)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {(data.historicoSalarial || []).map((h, i) => (
                  <tr key={i} className="hover:bg-slate-50">
                    <td className="p-3 font-mono font-bold text-slate-900">{h.competencia}</td>
                    <td className="p-3 font-mono">R$ {h.salarioBase?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                    <td className="p-3 font-mono">R$ {(h.gratificacao || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                    <td className="p-3 font-mono font-bold text-emerald-700">R$ {h.total?.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* CONTEÚDO DA SEÇÃO 5: HONORÁRIOS & PERÍCIA */}
      {activeSection === 'honorarios' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
          <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-3">
            Honorários Sucumbenciais, Periciais e Custas Processuais
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 text-sm">
            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Honorários Advocatícios Sucumbenciais (%)</label>
              <input
                type="number"
                value={data.honorarios?.honorariosAdvocaticiosPercentual ?? 15}
                onChange={(e) =>
                  onUpdateData({
                    ...data,
                    honorarios: {
                      ...data.honorarios,
                      honorariosAdvocaticiosPercentual: Number(e.target.value),
                    },
                  })
                }
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Honorários Periciais Apropriados (R$)</label>
              <input
                type="number"
                value={data.honorarios?.honorariosPericiaisValor ?? 2500}
                onChange={(e) =>
                  onUpdateData({
                    ...data,
                    honorarios: {
                      ...data.honorarios,
                      honorariosPericiaisValor: Number(e.target.value),
                    },
                  })
                }
                className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-emerald-500 font-mono font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase mb-1">Custas Processuais (%)</label>
              <input
                type="number"
                value={data.honorarios?.custasProcessuaisPercentual ?? 2}
                disabled
                className="w-full p-3 border border-slate-200 bg-slate-100 rounded-xl font-mono text-slate-600"
              />
            </div>
          </div>
        </div>
      )}

      {/* Modal para Adicionar Nova Verba */}
      {showAddVerbaModal && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="text-lg font-bold text-slate-900">Adicionar Nova Verba Trabalhista</h3>

            <form onSubmit={handleAddVerbaSubmit} className="space-y-4 text-xs">
              <div>
                <label className="block font-bold text-slate-700 mb-1">Nome da Verba</label>
                <input
                  type="text"
                  required
                  value={newVerba.nome}
                  onChange={(e) => setNewVerba({ ...newVerba, nome: e.target.value })}
                  placeholder="Ex: ADICIONAL NOTURNO (20%)"
                  className="w-full p-2.5 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-emerald-500 text-sm font-semibold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">Tipo</label>
                  <select
                    value={newVerba.tipo}
                    onChange={(e) => setNewVerba({ ...newVerba, tipo: e.target.value as TipoVerba })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  >
                    <option value="horas_extras">Horas Extras</option>
                    <option value="acumulo_funcao">Acúmulo de Função</option>
                    <option value="insalubridade">Insalubridade</option>
                    <option value="periculosidade">Periculosidade</option>
                    <option value="adicional_noturno">Adicional Noturno</option>
                    <option value="outro">Outro Título</option>
                  </select>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">Percentual (%)</label>
                  <input
                    type="number"
                    value={newVerba.percentual ?? ''}
                    onChange={(e) => setNewVerba({ ...newVerba, percentual: Number(e.target.value) })}
                    className="w-full p-2 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddVerbaModal(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 font-semibold rounded-lg hover:bg-slate-200"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-emerald-600 text-white font-semibold rounded-lg hover:bg-emerald-700 shadow-sm"
                >
                  Salvar e Inserir
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
