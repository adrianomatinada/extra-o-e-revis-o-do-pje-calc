import React, { useState } from 'react';
import { Upload, FileText, Sparkles, CheckCircle, AlertCircle, ArrowRight, Zap, ShieldCheck, Database, Layers } from 'lucide-react';
import { SAMPLE_CASES, SampleCase } from '../data/sampleCases';
import { ExtracaoTrabalhista } from '../types';

interface UploadSectionProps {
  onExtractionSuccess: (data: ExtracaoTrabalhista) => void;
  onSelectSampleCase: (sample: SampleCase) => void;
}

export const UploadSection: React.FC<UploadSectionProps> = ({
  onExtractionSuccess,
  onSelectSampleCase,
}) => {
  const [file, setFile] = useState<File | null>(null);
  const [pastedText, setPastedText] = useState<string>('');
  const [useProModel, setUseProModel] = useState<boolean>(false);
  const [applyOJ394, setApplyOJ394] = useState<boolean>(true);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setErrorMessage(null);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
      setErrorMessage(null);
    }
  };

  const handleStartExtraction = async () => {
    if (!file && !pastedText.trim()) {
      setErrorMessage('Por favor, selecione um arquivo PDF ou cole o texto de uma sentença/petição.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      setLoadingStep('Lendo documento e preparando canal de inteligência artificial...');
      await new Promise((r) => setTimeout(r, 600));

      setLoadingStep('Enviando dados para o modelo Gemini com Structured Outputs (JSON Schema)...');
      
      const formData = new FormData();
      if (file) {
        formData.append('file', file);
      }
      if (pastedText.trim()) {
        formData.append('textContent', pastedText.trim());
      }
      formData.append('useProModel', useProModel ? 'true' : 'false');
      formData.append('applyOJ394', applyOJ394 ? 'true' : 'false');

      const response = await fetch('/api/extract-document', {
        method: 'POST',
        body: formData,
      });

      setLoadingStep('Mapeando verbas deferidas, reflexos e prescrição quinquenal...');
      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.error || 'Ocorreu um erro ao processar o documento com IA.');
      }

      setLoadingStep('Sincronizando campos para validação e exportação no PJe-Calc...');
      await new Promise((r) => setTimeout(r, 400));

      onExtractionSuccess(result.data);
    } catch (err: any) {
      console.error('Erro de extração:', err);
      setErrorMessage(err.message || 'Falha na comunicação com o servidor de IA.');
    } finally {
      setIsLoading(false);
      setLoadingStep('');
    }
  };

  return (
    <div className="space-y-8 max-w-6xl mx-auto px-4 py-8">
      {/* Banner Principal */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white rounded-2xl p-6 sm:p-8 border border-slate-700/60 shadow-xl relative overflow-hidden">
        <div className="absolute -right-12 -top-12 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex items-center gap-3 text-emerald-400 font-semibold text-sm mb-2">
            <Zap className="w-5 h-5" />
            <span>Motor de Extração Trabalhista com IA de Alta Precisão</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-3">
            Transforme Sentenças em Arquivos Prontos para o PJe-Calc
          </h1>
          <p className="text-slate-300 max-w-3xl text-sm sm:text-base leading-relaxed">
            Faça o upload do PDF da sentença ou petição inicial. A Inteligência Artificial analisa a decisão, mapeia os marcos temporais, identifica todas as verbas deferidas com reflexos e prepara o schema para automação.
          </p>

          <div className="mt-6 flex flex-wrap gap-4 text-xs sm:text-sm text-slate-300">
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Validação da OJ 394 TST</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <Database className="w-4 h-4 text-emerald-400" />
              <span>Cálculo Automático de Prescrição Quinquenal</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700">
              <Layers className="w-4 h-4 text-emerald-400" />
              <span>Compatível com Extensões PJe-Calc Helper</span>
            </div>
          </div>
        </div>
      </div>

      {/* Casos de Teste Rápidos */}
      <div className="bg-slate-50 border border-slate-200 rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-emerald-600" />
            <h2 className="font-bold text-slate-900 text-base sm:text-lg">Deseja testar imediatamente sem fazer upload?</h2>
          </div>
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-500 bg-slate-200 px-2.5 py-1 rounded-full">
            Sentenças Pré-carregadas
          </span>
        </div>
        <p className="text-xs sm:text-sm text-slate-600 mb-4">
          Selecione um dos exemplos abaixo para visualizar instantaneamente o fluxo de extração, revisão de verbas e exportação para o PJe-Calc:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {SAMPLE_CASES.map((sample) => (
            <button
              key={sample.id}
              onClick={() => onSelectSampleCase(sample)}
              className="text-left bg-white p-4 rounded-xl border border-slate-200 hover:border-emerald-500 hover:shadow-md transition-all group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-1">
                  <span className="font-semibold text-slate-900 group-hover:text-emerald-700 text-sm">
                    {sample.titulo}
                  </span>
                  <span className="text-xs bg-emerald-50 text-emerald-700 font-medium px-2 py-0.5 rounded border border-emerald-200">
                    Testar
                  </span>
                </div>
                <p className="text-xs text-slate-500 line-clamp-2">{sample.subtitulo}</p>
              </div>
              <div className="mt-3 flex items-center text-xs font-semibold text-emerald-600 group-hover:translate-x-1 transition-transform">
                <span>Carregar estrutura do processo</span>
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* Form de Upload e Opções */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm space-y-6">
        <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
          <FileText className="w-5 h-5 text-emerald-600" />
          <span>Upload do Documento do Processo (PDF ou Texto)</span>
        </h2>

        {/* Area Drag and Drop */}
        <div
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          className={`border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer relative ${
            file
              ? 'border-emerald-500 bg-emerald-50/50'
              : 'border-slate-300 hover:border-emerald-400 bg-slate-50/60'
          }`}
        >
          <input
            type="file"
            accept=".pdf,.doc,.docx,.txt"
            onChange={handleFileChange}
            className="absolute inset-0 opacity-0 cursor-pointer w-full h-full"
          />
          <div className="flex flex-col items-center justify-center space-y-3">
            <div className={`p-4 rounded-full ${file ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-500'}`}>
              <Upload className="w-8 h-8" />
            </div>
            {file ? (
              <div>
                <p className="font-semibold text-slate-900 text-sm">{file.name}</p>
                <p className="text-xs text-emerald-600 font-medium mt-1">
                  {(file.size / (1024 * 1024)).toFixed(2)} MB • Arquivo pronto para envio
                </p>
              </div>
            ) : (
              <div>
                <p className="font-semibold text-slate-800 text-sm sm:text-base">
                  Arraste e solte a Sentença Trabalhista aqui ou <span className="text-emerald-600 underline">clique para procurar</span>
                </p>
                <p className="text-xs text-slate-500 mt-1">
                  Suporta arquivos PDF (Sentenças, Petições Iniciais, Acórdãos) até 25MB
                </p>
              </div>
            )}
          </div>
        </div>

        {/* Divisor Ou */}
        <div className="relative flex py-1 items-center">
          <div className="flex-grow border-t border-slate-200" />
          <span className="flex-shrink mx-4 text-slate-400 text-xs uppercase font-semibold">
            ou cole o texto bruto da decisão
          </span>
          <div className="flex-grow border-t border-slate-200" />
        </div>

        {/* Textarea para Colar Texto */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase mb-2">
            Texto da Sentença / Despacho Judicial
          </label>
          <textarea
            value={pastedText}
            onChange={(e) => {
              setPastedText(e.target.value);
              if (e.target.value.trim()) setErrorMessage(null);
            }}
            placeholder="Cole aqui o trecho ou relatório completo da sentença do PJe..."
            rows={4}
            className="w-full text-sm p-3.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 outline-none transition-all font-mono text-slate-800 bg-slate-50/50"
          />
        </div>

        {/* Opções de Configuração */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-2 gap-4">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={applyOJ394}
              onChange={(e) => setApplyOJ394(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-bold text-slate-800 block">Aplicar Tese Vinculante OJ 394 SDI-1 TST</span>
              <span className="text-xs text-slate-500">Mapeia ausência de repetição de DSR majorado nos reflexos</span>
            </div>
          </label>

          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={useProModel}
              onChange={(e) => setUseProModel(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
            />
            <div>
              <span className="text-xs font-bold text-slate-800 block">Ativar Modelo Gemini 3.1 Pro (Raciocínio Jurídico Avançado)</span>
              <span className="text-xs text-slate-500">Recomendado para sentenças complexas com múltiplos pedidos</span>
            </div>
          </label>
        </div>

        {/* Mensagens de Erro */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl text-xs sm:text-sm flex items-center gap-2">
            <AlertCircle className="w-5 h-5 flex-shrink-0 text-red-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Loader de Processamento */}
        {isLoading && (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 p-6 rounded-xl space-y-3 animate-pulse">
            <div className="flex items-center gap-3">
              <div className="w-6 h-6 border-3 border-emerald-600 border-t-transparent rounded-full animate-spin" />
              <span className="font-bold text-sm sm:text-base">Processando com Inteligência Artificial...</span>
            </div>
            <p className="text-xs text-emerald-800 font-mono bg-emerald-100/70 p-2.5 rounded-lg border border-emerald-200/50">
              {loadingStep}
            </p>
          </div>
        )}

        {/* Botão de Ação */}
        <button
          onClick={handleStartExtraction}
          disabled={isLoading}
          className={`w-full py-4 px-6 rounded-xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-2 text-base ${
            isLoading
              ? 'bg-slate-400 cursor-not-allowed'
              : 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] shadow-emerald-600/20'
          }`}
        >
          <Sparkles className="w-5 h-5" />
          <span>{isLoading ? 'Processando Documento...' : 'Iniciar Extração Inteligente para o PJe-Calc'}</span>
        </button>
      </div>
    </div>
  );
};
