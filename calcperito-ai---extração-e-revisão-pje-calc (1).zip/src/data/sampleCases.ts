import { ExtracaoTrabalhista } from '../types';

export interface SampleCase {
  id: string;
  titulo: string;
  subtitulo: string;
  categoria: 'sentenca' | 'peticao' | 'acordao';
  textoOriginal: string;
  extracaoEsperada: ExtracaoTrabalhista;
}

export const SAMPLE_CASES: SampleCase[] = [
  {
    id: 'sentenca-1',
    titulo: 'Sentença - Horas Extras, Acúmulo e OJ 394 TST',
    subtitulo: 'Ação Trabalhista TST - Montagens Elétricas e Instrumentação (15ª Região)',
    categoria: 'sentenca',
    textoOriginal: `PODER JUDICIÁRIO - JUSTIÇA DO TRABALHO
TRIBUNAL REGIONAL DO TRABALHO DA 15ª REGIÃO
2ª VARA DO TRABALHO DE PAULÍNIA / SP

PROCESSO Nº 0010454-82.2024.5.15.0122
RECLAMANTE: EDINEI MIRANDA SILVA
RECLAMADO: S. I. M. MONTAGENS ELETRICA E INSTRUMENTACAO INDUSTRIAL LTDA

SENTENÇA

I - RELATÓRIO
Dispensado o relatório, nos termos do artigo 852-I da CLT.

II - FUNDAMENTAÇÃO
1. MARCOS TEMPORAIS
O autor prestou serviços no período de 13/04/2023 a 19/10/2023, data da dispensa imotivada. Ação ajuizada em 18/12/2025. Não há prescrição quinquenal a declarar ante a brevidade da pactuação laboral.

2. ACÚMULO DE FUNÇÕES
Restou demonstrado que o Reclamante, contratado como Eletricista, exerceu concomitantemente atribuições de Encarregado de Equipe. Defiro o adicional por acúmulo de funções no percentual de 20% sobre o salário contratual (R$ 3.850,00), com reflexos diretos em Férias com 1/3, 13º Salário, Aviso Prévio e FGTS + 40%.

3. HORAS EXTRAS E ADICIONAL
Com base no depoimento testemunhal, fixo a jornada de trabalho de segunda a sábado das 07h00 às 19h00, com 45 minutos de intervalo intrajornada.
Defiro o pagamento de horas extras excedentes da 8ª diária e 44ª semanal, com adicional de 50%, apurando-se uma média de 42,86 horas extras mensais, utilizando o divisor 220.
Defiro reflexos em DSR, Férias + 1/3, 13º salário, Aviso Prévio e FGTS + 40%.
Observe-se rigorosamente a tese vinculante fixada na OJ 394 da SDI-1 do TST (não repercussão do DSR majorado pelas horas extras nas demais parcelas rescisórias/trabalhistas).

4. HONORÁRIOS E CUSTAS
Condeno a Reclamada ao pagamento de honorários advocatícios sucumbenciais no importe de 15% sobre o valor que resultar da liquidação.
Custas pela Reclamada no importe de 2% do valor da condenação. Concedo a gratuidade de justiça ao autor.`,
    extracaoEsperada: {
      id: 'demo-1',
      dataExtracao: '2026-07-29',
      nomeArquivo: 'Sentenca_0010454-82.2024.5.15.0122.pdf',
      processo: {
        numero: '0010454-82.2024.5.15.0122',
        reclamante: 'EDINEI MIRANDA SILVA',
        reclamado: 'S. I. M. MONTAGENS ELETRICA E INSTRUMENTACAO INDUSTRIAL LTDA',
        tribunal: 'TRT 15ª Região',
        vara: '2ª Vara do Trabalho de Paulínia',
        uf: 'SP'
      },
      datas: {
        admissao: '13/04/2023',
        demissao: '19/10/2023',
        ajuizamento: '18/12/2025',
        prescricaoQuinquenal: '18/12/2020 (Sem parcelas prescritas)',
        dataSentenca: '29/07/2026'
      },
      verbas: [
        {
          id: 'v1',
          nome: 'ACÚMULO DE FUNÇÕES',
          tipo: 'acumulo_funcao',
          percentual: 20,
          valorEstimado: 4620.00,
          baseCalculo: 'Salário Contratual (R$ 3.850,00)',
          oj394: false,
          reflexos: ['Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
          observacoes: 'Adicional de 20% por exercer atribuições de Encarregado',
          statusRevisao: 'aprovado'
        },
        {
          id: 'v2',
          nome: 'HORAS EXTRAS (50%)',
          tipo: 'horas_extras',
          percentual: 50,
          quantidadeMensal: 42.86,
          divisor: 220,
          valorEstimado: 12480.50,
          baseCalculo: 'Evolução Salarial + Adicional de Acúmulo',
          oj394: true,
          reflexos: ['DSR', 'Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
          observacoes: 'Jornada fixada das 07h às 19h com 45min intrajornada. Aplicar OJ 394 TST.',
          statusRevisao: 'aprovado'
        },
        {
          id: 'v3',
          nome: 'INTERVALO INTRAJORNADA (ART. 71, §4º CLT)',
          tipo: 'intervalo_intrajornada',
          percentual: 50,
          quantidadeMensal: 15,
          valorEstimado: 1950.00,
          baseCalculo: 'Salário hora normal com adicional de 50%',
          oj394: false,
          reflexos: ['Indenizatório sem reflexos (Lei 13.467/2017)'],
          observacoes: 'Supressão de 15 minutos do intervalo mínimo legal',
          statusRevisao: 'pendente'
        }
      ],
      historicoSalarial: [
        { competencia: '04/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '05/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '06/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '07/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '08/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '09/2023', salarioBase: 3850.00, total: 3850.00 },
        { competencia: '10/2023', salarioBase: 3850.00, total: 3850.00 }
      ],
      honorarios: {
        honorariosAdvocaticiosPercentual: 15,
        honorariosPericiaisValor: 2500,
        custasProcessuaisPercentual: 2,
        gratuidadeJustica: true,
        reclamanteGratuito: true
      },
      laudo: {
        resumoSentenca: 'Sentença parcial procedente da 2ª VT de Paulínia deferindo adicional por acúmulo de funções (20%) e 42,86 horas extras mensais com adicional de 50%.',
        fundamentacaoTecnica: 'Cálculos elaborados observando o divisor 220, vigência contratual de 13/04/2023 a 19/10/2023, incidência dos reflexos contratuais e aplicação expressa da Tese Vinculante da OJ 394 do TST.',
        conclusaoPericial: 'O valor bruto estimado dos créditos trabalhistas do Reclamante é de R$ 19.050,50, acrescido de FGTS + 40% (R$ 3.820,00) e Honorários Sucumbenciais de 15% (R$ 2.857,58).'
      },
      resumoCalculoEstimado: {
        totalPrincipalBruto: 17100.50,
        totalReflexos: 5680.00,
        totalFGTSComMulta: 3820.00,
        totalHonorarios: 2857.58,
        totalLiquidoReclamante: 26600.50,
        totalGeralCondenacao: 29458.08
      }
    }
  },
  {
    id: 'sentenca-2',
    titulo: 'Sentença - Adicional de Insalubridade & Diferença Salarial',
    subtitulo: 'Ação Trabalhista - Hospital e Maternidade São Lucas (2ª Região - SP)',
    categoria: 'sentenca',
    textoOriginal: `PODER JUDICIÁRIO - JUSTIÇA DO TRABALHO
TRT DA 2ª REGIÃO - 45ª VARA DO TRABALHO DE SÃO PAULO
PROCESSO Nº 1000892-14.2023.5.02.0045

RECLAMANTE: MARIANA DE OLIVEIRA SOUZA
RECLAMADO: HOSPITAL E MATERNIDADE SÃO LUCAS S.A.

SENTENÇA

I - MARCOS TEMPORAIS
Admissão: 02/05/2019. Demissão sem justa causa: 10/11/2023. Ajuizamento: 15/01/2024.
Prescrição quinquenal: Declarar prescritas as parcelas anteriores a 15/01/2019.

II - ADICIONAL DE INSALUBRIDADE
Com base no laudo pericial técnico juntado aos autos (ID f3a8901), que constatou o contato habitual e permanente com agentes biológicos infecciosos em ambiente hospitalar, defiro o Adicional de Insalubridade em grau máximo (40%), calculado sobre o salário mínimo nacional vigente em cada época da contratualidade.
Reflexos em Férias + 1/3, 13º Salários, Aviso Prévio indenizado, DSR e FGTS com a multa rescisória de 40%.

III - DIFERENÇA SALARIAL POR EQUIPARAÇÃO
A Reclamante comprovou exercer idêntica função ao paradigma indicado (Carlos Alberto Lima), com mesma produtividade e perfeição técnica. Defiro as diferenças salariais mensais no importe fixo de R$ 1.200,00 por mês trabalhado no período não prescrito.
Reflexos em Férias + 1/3, 13º Salários, Aviso Prévio e FGTS + 40%.

IV - HONORÁRIOS PERICIAIS E SUCUMBÊNCIA
Fixam-se honorários periciais em R$ 3.000,00 a cargo do Reclamado.
Honorários de sucumbência recíproca fixados em 10% para o patrono da Autora e 10% para a Ré.`,
    extracaoEsperada: {
      id: 'demo-2',
      dataExtracao: '2026-07-29',
      nomeArquivo: 'Sentenca_1000892-14.2023.5.02.0045.pdf',
      processo: {
        numero: '1000892-14.2023.5.02.0045',
        reclamante: 'MARIANA DE OLIVEIRA SOUZA',
        reclamado: 'HOSPITAL E MATERNIDADE SÃO LUCAS S.A.',
        tribunal: 'TRT 2ª Região',
        vara: '45ª Vara do Trabalho de São Paulo',
        uf: 'SP'
      },
      datas: {
        admissao: '02/05/2019',
        demissao: '10/11/2023',
        ajuizamento: '15/01/2024',
        prescricaoQuinquenal: '15/01/2019',
        dataSentenca: '29/07/2026'
      },
      verbas: [
        {
          id: 'v2-1',
          nome: 'ADICIONAL DE INSALUBRIDADE (40% Grau Máximo)',
          tipo: 'insalubridade',
          percentual: 40,
          valorEstimado: 23520.00,
          baseCalculo: 'Salário Mínimo Nacional Vigente',
          oj394: false,
          reflexos: ['DSR', 'Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
          observacoes: 'Insalubridade apurada por Perícia Médica Judicial (Agentes Biológicos)',
          statusRevisao: 'aprovado'
        },
        {
          id: 'v2-2',
          nome: 'DIFERENÇA SALARIAL (Equiparação Salarial)',
          tipo: 'diferenca_salarial',
          valorEstimado: 64800.00,
          baseCalculo: 'Diferença fixa de R$ 1.200,00 / mês',
          oj394: false,
          reflexos: ['Férias + 1/3', '13º Salário', 'Aviso Prévio', 'FGTS + 40%'],
          observacoes: 'Paradigma: Carlos Alberto Lima. Período não prescrito.',
          statusRevisao: 'aprovado'
        }
      ],
      historicoSalarial: [
        { competencia: '2020 (Média)', salarioBase: 3100.00, total: 3100.00 },
        { competencia: '2021 (Média)', salarioBase: 3300.00, total: 3300.00 },
        { competencia: '2022 (Média)', salarioBase: 3550.00, total: 3550.00 },
        { competencia: '2023 (Média)', salarioBase: 3800.00, total: 3800.00 }
      ],
      honorarios: {
        honorariosAdvocaticiosPercentual: 10,
        honorariosPericiaisValor: 3000,
        custasProcessuaisPercentual: 2,
        gratuidadeJustica: true,
        reclamanteGratuito: true
      },
      laudo: {
        resumoSentenca: 'Sentença procedendo Adicional de Insalubridade em grau máximo (40% do salário mínimo) e Diferenças Salariais por Equiparação no valor de R$ 1.200,00/mês.',
        fundamentacaoTecnica: 'Insalubridade devida sobre a evolução do salário mínimo nacional. Equiparação com incidência nos haveres rescisórios e contratuais do período de 02/05/2019 a 10/11/2023.',
        conclusaoPericial: 'Crédito exequendo apurado no importe bruto de R$ 88.320,00 mais FGTS + 40% (R$ 14.131,20) e Honorários de R$ 8.832,00.'
      },
      resumoCalculoEstimado: {
        totalPrincipalBruto: 88320.00,
        totalReflexos: 21400.00,
        totalFGTSComMulta: 14131.20,
        totalHonorarios: 8832.00,
        totalLiquidoReclamante: 123851.20,
        totalGeralCondenacao: 135683.20
      }
    }
  }
];
