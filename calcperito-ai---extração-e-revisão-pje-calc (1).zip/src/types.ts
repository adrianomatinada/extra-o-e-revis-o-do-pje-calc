/**
 * Tipos de Dados para o Calculista AI / PJe-Calc Extração Trabalhista
 */

export interface ProcessoInfo {
  numero: string;
  reclamante: string;
  reclamado: string;
  tribunal?: string;
  vara?: string;
  uf?: string;
  municipio?: string;
  valorCausa?: number | string;
}

export interface DatasProcesso {
  admissao: string; // YYYY-MM-DD or DD/MM/YYYY
  demissao: string;
  ajuizamento: string;
  prescricaoQuinquenal?: string;
  dataSentenca?: string;
  dataCalculo?: string;
}

export type TipoVerba = 
  | 'horas_extras' 
  | 'acumulo_funcao' 
  | 'insalubridade' 
  | 'periculosidade' 
  | 'adicional_noturno' 
  | 'diferenca_salarial' 
  | 'intervalo_intrajornada' 
  | 'danos_morais' 
  | 'multa_art_477' 
  | 'multa_art_467' 
  | 'valor_fixo' 
  | 'outro';

export interface VerbaDeferida {
  id: string;
  nome: string;
  tipo: TipoVerba;
  percentual?: number | null;
  valorEstimado?: number | null;
  quantidadeMensal?: number | null; // e.g. 42.86 horas extras/mês
  divisor?: number | null; // e.g. 220, 180, 150
  baseCalculo?: string;
  oj394: boolean; // SDI-1 TST OJ 394 (não repetição do DSR majorado)
  reflexos: string[]; // ["Férias", "13º Salário", "Aviso Prévio", "FGTS + 40%", "DSR"]
  observacoes?: string;
  statusRevisao: 'pendente' | 'aprovado' | 'editado';
}

export interface HistoricoSalarialItem {
  competencia: string; // MM/YYYY
  salarioBase: number;
  gratificacao?: number;
  total: number;
}

export interface HonorariosEPericia {
  honorariosAdvocaticiosPercentual: number; // e.g. 15%
  honorariosPericiaisValor: number; // e.g. R$ 2.500,00
  custasProcessuaisPercentual: number; // e.g. 2%
  gratuidadeJustica: boolean;
  reclamanteGratuito?: boolean;
}

export interface LaudoTecnico {
  resumoSentenca: string;
  fundamentacaoTecnica: string;
  conclusaoPericial: string;
}

export interface ExtracaoTrabalhista {
  id: string;
  dataExtracao: string;
  nomeArquivo?: string;
  processo: ProcessoInfo;
  datas: DatasProcesso;
  verbas: VerbaDeferida[];
  historicoSalarial: HistoricoSalarialItem[];
  honorarios: HonorariosEPericia;
  laudo: LaudoTecnico;
  resumoCalculoEstimado?: {
    totalPrincipalBruto: number;
    totalReflexos: number;
    totalFGTSComMulta: number;
    totalHonorarios: number;
    totalLiquidoReclamante: number;
    totalGeralCondenacao: number;
  };
}
