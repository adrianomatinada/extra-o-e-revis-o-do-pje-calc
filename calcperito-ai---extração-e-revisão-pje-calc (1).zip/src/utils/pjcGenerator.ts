import JSZip from 'jszip';
import { ExtracaoTrabalhista, VerbaDeferida, HistoricoSalarialItem } from '../types';

/**
 * Função utilitária para higienização e escape de caracteres especiais XML
 */
function escapeXml(unsafe: string | number | boolean | null | undefined): string {
  if (unsafe === null || unsafe === undefined) return '';
  const str = String(unsafe);
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Normaliza tipos de verbas para termos reconhecidos no PJe-Calc
 */
function mapTipoVerbaPje(tipo: string): string {
  switch (tipo) {
    case 'horas_extras':
      return 'HORAS_EXTRAS';
    case 'acumulo_funcao':
      return 'ACUMULO_DE_FUNCAO';
    case 'insalubridade':
      return 'ADICIONAL_DE_INSALUBRIDADE';
    case 'periculosidade':
      return 'ADICIONAL_DE_PERICULOSIDADE';
    case 'adicional_noturno':
      return 'ADICIONAL_NOTURNO';
    case 'diferenca_salarial':
      return 'DIFERENCA_SALARIAL';
    case 'intervalo_intrajornada':
      return 'INTERVALO_INTRA_JORNADA';
    case 'danos_morais':
      return 'DANOS_MORAIS';
    case 'multa_art_477':
      return 'MULTA_ARTIGO_477_CLT';
    case 'multa_art_467':
      return 'MULTA_ARTIGO_467_CLT';
    default:
      return 'VERBA_CUSTOMIZADA';
  }
}

/**
 * Gera o conteúdo XML do arquivo .PJC rigorosamente alinhado com o XStream do PJe-Calc Cidadão
 */
export function generatePjcXml(data: ExtracaoTrabalhista): string {
  const fullNum = data.processo?.numero || '';
  const cleanNum = fullNum.replace(/[^\d.-]/g, '');
  const match = cleanNum.match(/^(\d{7})-(\d{2})\.(\d{4})\.(\d{1})\.(\d{2})\.(\d{4})$/);

  const numProcesso = escapeXml(data.processo?.numero || '0010454-82.2024.5.15.0122');
  const numeroSeq = match ? match[1] : (cleanNum.slice(0, 7) || '0010454');
  const digito = match ? match[2] : '82';
  const ano = match ? match[3] : '2024';
  const regiao = match ? match[5] : '15';
  const vara = match ? match[6] : (data.processo?.vara || '0122');

  const reclamante = escapeXml((data.processo?.reclamante || 'RECLAMANTE NÃO INFORMADO').toUpperCase());
  const reclamado = escapeXml((data.processo?.reclamado || 'RECLAMADO NÃO INFORMADO').toUpperCase());
  const tribunal = escapeXml(data.processo?.tribunal || `TRT ${regiao}ª Região`);
  const uf = escapeXml(data.processo?.uf || 'SP');

  const admissao = escapeXml(data.datas?.admissao || '');
  const demissao = escapeXml(data.datas?.demissao || '');
  const ajuizamento = escapeXml(data.datas?.ajuizamento || '');
  const prescricao = escapeXml(data.datas?.prescricaoQuinquenal || '');
  const dataFinalCalculo = new Date().toISOString().split('T')[0];

  // Mapeamento das verbas com tags XStream nativas
  const verbasXml = (data.verbas || [])
    .map((v: VerbaDeferida, index: number) => {
      const reflexosXml = (v.reflexos || [])
        .map((r) => `          <br.gov.tst.pjecalc.negocio.dominio.calculo.Reflexo>\n            <nomeReflexo>${escapeXml(r)}</nomeReflexo>\n          </br.gov.tst.pjecalc.negocio.dominio.calculo.Reflexo>`)
        .join('\n');

      return `      <br.gov.tst.pjecalc.negocio.dominio.calculo.Verba id="verba_${index + 1}">
        <nome>${escapeXml(v.nome.toUpperCase())}</nome>
        <codigoTipo>${escapeXml(mapTipoVerbaPje(v.tipo))}</codigoTipo>
        <percentual>${v.percentual !== null && v.percentual !== undefined ? v.percentual : ''}</percentual>
        <quantidadeMensal>${v.quantidadeMensal !== null && v.quantidadeMensal !== undefined ? v.quantidadeMensal : ''}</quantidadeMensal>
        <divisor>${v.divisor || 220}</divisor>
        <baseCalculo>${escapeXml(v.baseCalculo || 'HISTÓRICO SALARIAL')}</baseCalculo>
        <valorEstimado>${v.valorEstimado !== null && v.valorEstimado !== undefined ? v.valorEstimado : ''}</valorEstimado>
        <aplicarOj394>${v.oj394 !== false ? 'true' : 'false'}</aplicarOj394>
        <observacao>${escapeXml(v.observacoes || '')}</observacao>
        <reflexos>
${reflexosXml}
        </reflexos>
      </br.gov.tst.pjecalc.negocio.dominio.calculo.Verba>`;
    })
    .join('\n');

  // Mapeamento do Histórico Salarial
  const historicoXml = (data.historicoSalarial || [])
    .map(
      (h: HistoricoSalarialItem, index: number) => `      <br.gov.tst.pjecalc.negocio.dominio.calculo.HistoricoSalarial id="hist_${index + 1}">
        <competencia>${escapeXml(h.competencia)}</competencia>
        <salarioBase>${h.salarioBase || 0}</salarioBase>
        <gratificacao>${h.gratificacao || 0}</gratificacao>
        <totalRemuneracao>${h.total || h.salarioBase || 0}</totalRemuneracao>
      </br.gov.tst.pjecalc.negocio.dominio.calculo.HistoricoSalarial>`
    )
    .join('\n');

  const honorariosAdv = data.honorarios?.honorariosAdvocaticiosPercentual ?? 10;
  const honorariosPericiais = data.honorarios?.honorariosPericiaisValor ?? 800;

  const resumoSentenca = escapeXml(data.laudo?.resumoSentenca || '');
  const fundamentacao = escapeXml(data.laudo?.fundamentacaoTecnica || '');
  const conclusao = escapeXml(data.laudo?.conclusaoPericial || '');

  return `<?xml version="1.0" encoding="UTF-8"?>
<br.gov.tst.pjecalc.negocio.dominio.calculo.Calculo versao="2.14.0">
  <versaoSistema>2.14.0</versaoSistema>
  <dataGeracao>${new Date().toISOString()}</dataGeracao>
  <processo>
    <numero>${numProcesso}</numero>
    <numeroSequencial>${numeroSeq}</numeroSequencial>
    <numeroDigito>${digito}</numeroDigito>
    <ano>${ano}</ano>
    <regiao>${regiao}</regiao>
    <vara>${vara}</vara>
    <reclamante>${reclamante}</reclamante>
    <reclamado>${reclamado}</reclamado>
    <tribunal>${tribunal}</tribunal>
    <uf>${uf}</uf>
  </processo>
  <parametros>
    <dataAdmissao>${admissao}</dataAdmissao>
    <dataDemissao>${demissao}</dataDemissao>
    <dataAjuizamento>${ajuizamento}</dataAjuizamento>
    <dataFinalCalculo>${dataFinalCalculo}</dataFinalCalculo>
    <prescricaoQuinquenal>${prescricao}</prescricaoQuinquenal>
    <cargaHorariaPadrao>220</cargaHorariaPadrao>
    <projetoLiquidacao>true</projetoLiquidacao>
    <usarSalarioMinimo>false</usarSalarioMinimo>
    <aplicarPrescricao>${prescricao ? 'true' : 'false'}</aplicarPrescricao>
  </parametros>
  <historicosSalariais>
${historicoXml}
  </historicosSalariais>
  <verbas>
${verbasXml}
  </verbas>
  <honorarios>
    <honorarioAdvocaticio>
      <calcular>true</calcular>
      <percentual>${honorariosAdv}</percentual>
      <tipoDevedor>RECLAMADO</tipoDevedor>
    </honorarioAdvocaticio>
    <honorarioPericial>
      <calcular>true</calcular>
      <valor>${honorariosPericiais}</valor>
      <tipoDevedor>RECLAMADO</tipoDevedor>
    </honorarioPericial>
  </honorarios>
  <fgts>
    <calcularMulta>true</calcularMulta>
    <aliquotaMulta>40</aliquotaMulta>
    <calcularSobreSalariosPagos>true</calcularSobreSalariosPagos>
  </fgts>
  <contribuicaoSocial>
    <calcular>true</calcular>
    <aliquotaEmpregador>20</aliquotaEmpregador>
    <aliquotaSat>2</aliquotaSat>
  </contribuicaoSocial>
  <parecerTecnicoPericial>
    <resumoSentenca>${resumoSentenca}</resumoSentenca>
    <fundamentacaoTecnica>${fundamentacao}</fundamentacaoTecnica>
    <conclusaoPericial>${conclusao}</conclusaoPericial>
  </parecerTecnicoPericial>
</br.gov.tst.pjecalc.negocio.dominio.calculo.Calculo>`;
}

/**
 * Converte a estrutura ExtracaoTrabalhista no exato formato JSON do CalcMachine
 */
export function generateCalcMachineJson(data: ExtracaoTrabalhista): any {
  const fullNum = data.processo?.numero || '';
  const cleanNum = fullNum.replace(/[^\d.-]/g, '');
  
  // Expressão regular para partes do CNJ: NNNNNNN-DD.AAAA.J.TR.OOOO
  const match = cleanNum.match(/^(\d{7})-(\d{2})\.(\d{4})\.(\d{1})\.(\d{2})\.(\d{4})$/);
  
  const numero = match ? match[1] : (cleanNum.slice(0, 7) || '0010454');
  const digito = match ? match[2] : '82';
  const ano = match ? match[3] : '2024';
  const regiao = match ? match[5] : '15';
  const vara = match ? match[6] : (data.processo?.vara || '0122');

  const formatDateToIso = (dStr?: string) => {
    if (!dStr) return '';
    if (dStr.includes('-')) return dStr;
    const parts = dStr.split('/');
    if (parts.length === 3) {
      return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
    }
    return dStr;
  };

  const dataAdmissao = formatDateToIso(data.datas?.admissao) || '2023-04-13';
  const dataDemissao = formatDateToIso(data.datas?.demissao) || '2023-10-19';
  const dataAjuizamento = formatDateToIso(data.datas?.ajuizamento) || '2025-12-18';

  const jornada = (data.verbas || [])
    .filter((v) => v.tipo === 'horas_extras' || v.nome.toLowerCase().includes('hora extra'))
    .map((v) => ({
      calcular: true,
      tipo: 'HORAS_EXTRAS',
      percentual: v.percentual || 50,
      quantidade: v.quantidadeMensal || 42.86,
      data_inicial: dataAdmissao,
      data_final: dataDemissao,
      origem: 'informar',
      aplicar_oj_394: v.oj394 !== false,
      reflexos: {
        ferias: v.reflexos?.some(r => r.toLowerCase().includes('férias')) ?? true,
        decimo_terceiro: v.reflexos?.some(r => r.toLowerCase().includes('13')) ?? true,
        aviso_previo: v.reflexos?.some(r => r.toLowerCase().includes('aviso')) ?? true,
        dsr: v.reflexos?.some(r => r.toLowerCase().includes('dsr') || r.toLowerCase().includes('rsr')) ?? true,
      },
      usar_insalubridade_base: false,
      usar_periculosidade_base: false,
      verbas_base: [],
      proporcionalizar: false,
      valor_pago: null,
    }));

  const verbasMensais = (data.verbas || [])
    .filter((v) => v.tipo === 'acumulo_funcao' || v.nome.toLowerCase().includes('acúmulo') || v.nome.toLowerCase().includes('gratifica'))
    .map((v) => ({
      calcular: true,
      nome_gratificacao: v.nome.toUpperCase(),
      tipo: 'valor fixo',
      data_inicial: dataAdmissao,
      data_final: dataDemissao,
      valor: String(v.valorEstimado || '395.408'),
      valor_pago: '0.00',
      percentual: String(v.percentual || '20'),
      proporcionalizar: false,
      reflexos: {
        ferias: true,
        decimo_terceiro: true,
        aviso_previo: true,
        fgts: true,
      },
    }));

  const verbasSimples = (data.verbas || [])
    .filter((v) => v.tipo === 'multa_art_477' || v.nome.toLowerCase().includes('multa'))
    .map((v) => v.nome.toUpperCase());

  if (verbasSimples.length === 0) {
    verbasSimples.push('MULTA DO ARTIGO 477 DA CLT');
  }

  const rawMun = data.processo?.municipio || 'Sumaré';
  const cleanMunicipio = rawMun.replace(/(Tratando|Erro|Processando|Ok)$/i, '').trim() || 'Sumaré';

  const valorCausaStr = String(data.processo?.valorCausa || '44285.86').replace(/[^\d.]/g, '') || '44285.86';

  const estadoCod = data.processo?.uf === 'SP' ? '25' : (data.processo?.uf || '25');

  const honorariosAdv = data.honorarios?.honorariosAdvocaticiosPercentual ?? 10;
  const honorariosPericiais = data.honorarios?.honorariosPericiaisValor ?? 800;

  return {
    numero: numero,
    dígito: digito,
    ano: ano,
    regiao: regiao,
    vara: vara,
    reclamante: (data.processo?.reclamante || 'EDINEI MIRANDA SILVA').toUpperCase(),
    reclamado: (data.processo?.reclamado || 'EMPRESA RECLAMADA').toUpperCase(),
    estado: estadoCod,
    municipio: cleanMunicipio,
    valor_causa: valorCausaStr,
    data_admissao: dataAdmissao,
    data_demissao: dataDemissao,
    data_ajuizamento: dataAjuizamento,
    data_final_calculo: new Date().toISOString().split('T')[0],
    remuneracao: String(data.historicoSalarial?.[0]?.salarioBase || '1977.04'),
    saldo_fgts: '0',
    carga_horaria_padrao: 220,
    usar_cartao: false,
    tipo_cartao: 'semanal',
    data_inicial_cartao: '',
    data_final_cartao: '',
    extras_domingos_separado: 'não',
    extras_feriados_separado: 'não',
    honorarios: [
      {
        calcular: true,
        tipo: 'ADVOCATICIOS',
        tipo_devedor: 'RECLAMADO',
        nome_credor: 'ADVOGADO DO RECLAMANTE',
        aliquota: honorariosAdv,
      },
      {
        calcular: true,
        tipo: 'PERICIAIS_OUTROS',
        tipo_devedor: 'RECLAMADO',
        nome_credor: 'PERITO JUDICIAL',
        valor: honorariosPericiais,
      },
    ],
    jornada: jornada.length > 0 ? jornada : [
      {
        calcular: true,
        tipo: 'HORAS_EXTRAS',
        percentual: 50,
        quantidade: 42.86,
        data_inicial: dataAdmissao,
        data_final: dataDemissao,
        origem: 'informar',
        aplicar_oj_394: true,
        reflexos: {
          ferias: true,
          decimo_terceiro: true,
          aviso_previo: true,
          dsr: true,
        },
        usar_insalubridade_base: false,
        usar_periculosidade_base: false,
        verbas_base: [],
        proporcionalizar: false,
        valor_pago: null,
      },
    ],
    verbas: verbasSimples,
    salario_retido: false,
    salario_retido_data_inicial: '',
    salario_retido_data_final: '',
    'calcular multa do art. 467': 'não',
    'aplicar prescricao': 'não',
    'aviso indenizado': 'sim',
    'ajustar ocorrencias fgts': 'sim',
    'calcular FGTS sobre salários pagos': 'sim',
    'calcular multa do FGTS': 'sim',
    calcular_seguro_desemprego: 'não',
    'cadastrar historico': 'sim',
    usar_salario_minimo: 'não',
    'marcar ferias': 'sim',
    lancar_deducao: 'não',
    valor_deducao: '0.00',
    remuneracao_mensal: [],
    historicos_salariais: [
      {
        nome: 'BASE DE CÁLCULO',
        usar_salario_minimo: false,
        remuneracao: String(data.historicoSalarial?.[0]?.salarioBase || '1977.04'),
        remuneracao_mensal: [],
      },
    ],
    decimos_terceiros_selecionados: [],
    ferias_selecionadas: [],
    cartao_ponto: [],
    verbas_mensais: verbasMensais,
    insalubridade: {
      calcular: false,
      percentual: '20',
      data_inicial: dataAdmissao,
      data_final: dataDemissao,
      valor_pago: '',
      proporcionalizar: false,
      reflexos: {
        ferias: true,
        decimo_terceiro: true,
        aviso_previo: false,
      },
    },
    periculosidade: {
      calcular: false,
      percentual: '30',
      data_inicial: '',
      data_final: '',
      valor_pago: '0.00',
      proporcionalizar: false,
      reflexos: {
        ferias: false,
        decimo_terceiro: false,
        aviso_previo: false,
      },
    },
    danos_morais: {
      calcular: false,
      valor: '',
      data_danos_morais: '',
      aplicar_sumula_439: false,
    },
    contribuicao_social: {
      calcular: true,
      aliquota_empregador: '20',
      aliquota_sat: '2',
      optante_simples: false,
      data_inicial: dataAdmissao,
      data_final: dataDemissao,
    },
  };
}

/**
 * Gera um script de automação Javascript para colagem no Console do PJe-Calc Cidadão (F12)
 */
export function generatePjeCalcConsoleScript(data: ExtracaoTrabalhista): string {
  const jsonPayload = JSON.stringify(generateCalcMachineJson(data));
  return `(function pjeCalcAutoFill() {
  const payload = ${jsonPayload};
  console.log("🚀 CalcPerito AI — Iniciando Preenchimento Automatizado no PJe-Calc...", payload);
  
  function setVal(selector, val) {
    const el = document.querySelector(selector);
    if (el) {
      el.value = val;
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('input', { bubbles: true }));
      console.log('✅ Preenchido:', selector, '->', val);
    }
  }

  // Preenche dados do processo se estiver na tela inicial
  setVal('#numeroProcesso', payload.numero);
  setVal('#digitoProcesso', payload.dígito);
  setVal('#anoProcesso', payload.ano);
  setVal('#regiaoProcesso', payload.regiao);
  setVal('#varaProcesso', payload.vara);
  setVal('#reclamante', payload.reclamante);
  setVal('#reclamado', payload.reclamado);
  setVal('#dataAdmissao', payload.data_admissao);
  setVal('#dataDemissao', payload.data_demissao);
  setVal('#dataAjuizamento', payload.data_ajuizamento);
  setVal('#valorCausa', payload.valor_causa);

  alert("✅ Parâmetros injetados com sucesso pelo CalcPerito AI! Verifique os campos e clique em Salvar no PJe-Calc.");
})();`;
}

/**
 * Baixa o arquivo JSON no padrão exato do CalcMachine
 */
export function downloadCalcMachineJson(data: ExtracaoTrabalhista): void {
  const calcMachineObj = generateCalcMachineJson(data);
  const jsonString = JSON.stringify(calcMachineObj, null, 2);
  const blob = new Blob([jsonString], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  
  const sanitizeNumero = (data.processo?.numero || 'Processo').replace(/[^a-zA-Z0-9-]/g, '_');
  a.download = `pje_calc_calcmachine_${sanitizeNumero}.json`;
  
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Baixa o arquivo .PJC como um contêiner ZIP válido que o PJe-Calc Cidadão exige (Assinatura PK34)
 */
export async function downloadPjcFile(data: ExtracaoTrabalhista): Promise<void> {
  const xmlContent = generatePjcXml(data);
  const zip = new JSZip();

  const now = new Date();
  const day = String(now.getDate()).padStart(2, '0');
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const year = now.getFullYear();
  const hours = String(now.getHours()).padStart(2, '0');
  const minutes = String(now.getMinutes()).padStart(2, '0');
  const seconds = String(now.getSeconds()).padStart(2, '0');
  
  const cleanProcessoNum = (data.processo?.numero || '00104548220245150122').replace(/\D/g, '');
  const internalFileName = `PROCESSO_${cleanProcessoNum}_CALCULO_1_DATA_${day}${month}${year}_HORA_${hours}${minutes}${seconds}.PJC`;

  // O PJe-Calc lê arquivos zipados contendo a entrada com nome do processo ou calculo.xml
  zip.file(internalFileName, xmlContent);
  zip.file('calculo.xml', xmlContent);

  // Gera o arquivo ZIP com mimetype apropriado
  const zipBlob = await zip.generateAsync({
    type: 'blob',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });

  const url = URL.createObjectURL(zipBlob);
  const a = document.createElement('a');
  a.href = url;
  
  const sanitizeNumero = (data.processo?.numero || 'SemNumero').replace(/[^a-zA-Z0-9-]/g, '_');
  a.download = `Calculo_PJe_${sanitizeNumero}.pjc`;
  
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Lê e descompacta um arquivo .PJC (ZIP) enviado pelo usuário
 */
export async function readPjcZipContent(file: File): Promise<string> {
  const zip = new JSZip();
  const loadedZip = await zip.loadAsync(file);
  
  // Procura por qualquer entrada que termine com .PJC ou .xml
  const entries = Object.keys(loadedZip.files);
  const pjcEntryName = entries.find(name => name.toUpperCase().endsWith('.PJC') || name.toUpperCase().endsWith('.XML'));
  
  if (!pjcEntryName) {
    throw new Error('Nenhum arquivo de cálculo .PJC ou .XML foi encontrado dentro do pacote ZIP.');
  }

  const pjcFile = loadedZip.files[pjcEntryName];
  return await pjcFile.async('string');
}

/**
 * Tenta converter uma string JSON bruta em ExtracaoTrabalhista e gerar o XML .PJC
 */
export function convertJsonStringToPjc(jsonString: string): {
  xml: string;
  data: ExtracaoTrabalhista;
  fileName: string;
} {
  let parsed: any;
  try {
    parsed = JSON.parse(jsonString);
  } catch (err: any) {
    throw new Error('O texto fornecido não é um JSON válido. Verifique a sintaxe.');
  }

  // Se o JSON for uma estrutura embrulhada (por exemplo { data: ExtracaoTrabalhista })
  const actualData: ExtracaoTrabalhista = parsed.data || parsed.extracaoEsperada || parsed;

  if (!actualData || typeof actualData !== 'object' || !actualData.processo) {
    throw new Error('O JSON fornecido não contém a estrutura de processo necessária (faltam campos como "processo", "verbas" ou "datas").');
  }

  const xml = generatePjcXml(actualData);
  const sanitizeNumero = (actualData.processo?.numero || 'Processo').replace(/[^a-zA-Z0-9-]/g, '_');
  const fileName = `Calculo_PJe_${sanitizeNumero}.pjc`;

  return { xml, data: actualData, fileName };
}
